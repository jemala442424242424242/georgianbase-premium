import mysql.connector
import os
import numpy as np
import sys
import threading
import json



host = "127.0.0.1"
user = "root"
passwd = ""
database = "geobase"


db = mysql.connector.connect(
    host=host,
    user=user,
    passwd = passwd,
    database= database
)

kurs = db.cursor()
kurs.execute("SELECT * FROM acc_upgrades;")

acc_upgradesnf = kurs.fetchall()
if acc_upgradesnf == []:
    acc_upgradesnpb = np.array([]).tobytes()
    acc_upgrades_size = 33
else:
    acc_upgradesn = np.array(acc_upgradesnf)

    acc_upgradesnp = np.core.records.fromarrays(acc_upgradesn.transpose()
                                            ,formats = "int32, int32, int32, int32 ")

    acc_upgradesnpb = acc_upgradesnp.tobytes()

    acc_upgrades_size = sys.getsizeof(acc_upgradesnpb)










kurs.execute("SELECT * FROM ref_invites;")

ref_invitesf = kurs.fetchall()
if ref_invitesf == []:
    ref_invitesnpb = np.array([]).tobytes()
    ref_invites_size = 33

else:    
    ref_invitesn = np.array(ref_invitesf)

    ref_invitesnp = np.core.records.fromarrays(ref_invitesn.transpose()
                                            ,formats = "int32, int32 ")

    ref_invitesnpb = ref_invitesnp.tobytes()

    ref_invites_size = sys.getsizeof(ref_invitesnpb)













kurs.execute("SELECT request_infos_id, request_infos_ip, request_infos_request_time FROM request_infos;")

request_infosf = kurs.fetchall()

if request_infosf == []:
    request_infosnpb = np.array([]).tobytes()
    request_infos_size = 33
else:
    request_infosn = np.array(request_infosf)

    request_infosnp = np.core.records.fromarrays(request_infosn.transpose()
                                            ,formats = "int32, <U16, int32 ")
    request_infosnpb = request_infosnp.tobytes()

    request_infos_size = sys.getsizeof(request_infosnpb)












kurs.execute("SELECT row_id , saver_id, piradobis_nomeri_id FROM saved_rows;")

saved_rowsf = kurs.fetchall()

if saved_rowsf == []:
    saved_rowsnpb = np.array([]).tobytes()
    saved_rows_size = 33
else:

    saved_rowsn = np.array(saved_rowsf)

    saved_rowsnp = np.core.records.fromarrays(saved_rowsn.transpose()
                                            ,formats = "int32, int32, int64 ")

    saved_rowsnpb = saved_rowsnp.tobytes()

    saved_rows_size = sys.getsizeof(saved_rowsnpb)












kurs.execute("SELECT search_id , searcher_ip FROM searches;")

searchesf = kurs.fetchall()

if searchesf == []:
    searchesnpb = np.array([]).tobytes()
    searches_size = 33
else:
    searchesn = np.array(searchesf)

    searchesnp = np.core.records.fromarrays(searchesn.transpose()
                                            ,formats = "int32, <U16 ")

    searchesnpb = searchesnp.tobytes()

    searches_size = sys.getsizeof(searchesnpb)















kurs.execute("SELECT id, ip, mail, password, vcode, user_creation_time, refstr FROM users;")

usersf = kurs.fetchall()
if usersf == []:
    usersnpb = np.array([]).tobytes()
    users_size = 33
else:
    usersn = np.array(usersf)

    usersnp = np.core.records.fromarrays(usersn.transpose()
                                            ,formats = "int32, <U16, <U40, <U100, int32, int32, <U50 ")

    usersnpb = usersnp.tobytes()

    users_size= sys.getsizeof(usersnpb)


# data_measurements = {
#     "acc_upgrades" : acc_upgradesnpb,
#     "ref_invites" : ref_invitesnpb,
#     "request_infos" : request_infosnpb,
#     "saved_rows" : saved_rowsnpb,
#     "searches" : searchesnpb,
#     "users" : usersnpb
# }

with open("db_store/acc_upgradesnpb.dll","w+b") as acc_upgradesnpbf:
    acc_upgradesnpbf.write(acc_upgradesnpb)
with open("db_store/ref_invitesnpb.dll","w+b") as ref_invitesnpbf:
    ref_invitesnpbf.write(ref_invitesnpb)
with open("db_store/request_infosnpb.dll","w+b") as request_infosnpbf:
    request_infosnpbf.write(request_infosnpb)

with open("db_store/saved_rowsnpb.dll","w+b") as saved_rowsnpbf:
    saved_rowsnpbf.write(saved_rowsnpb)
with open("db_store/searchesnpb.dll","w+b") as searchesnpbf:
    searchesnpbf.write(searchesnpb)
with open("db_store/usersnpb.dll","w+b") as usersnpbf:
    usersnpbf.write(usersnpb)







































print("done")