

import mysql.connector
import threading
import time

host = "127.0.0.1"
user = "root"
passwd = ""
database = "geobase"


db = mysql.connector.connect(
    host=host,
    user=user,
    passwd = passwd,
    database= database
)

# db.execute('set max_allowed_packet=67108864')
kurs = db.cursor()
# kurs.execute('set max_allowed_packet=67108864')
# kurs.execute("INSERT INTO users(mail) VALUES('ae')")
def func():
    kurs = db.cursor()
    
    kurs.execute("INSERT INTO users(mail) VALUES('ae')")
    # print("demage")
    # kurs.close()
    print("insertad")


# threading.Thread(target=func).start()

for i in range(0,411):
    # print("i")
    # def func():
    #     kurs = db.cursor()
    #     kurs.execute("INSERT INTO users(mail) VALUES('ae')")
    #     kurs.close()

    # func()
    a = threading.Thread(target=func)
    a.start()
    # a.join()
print("done")
while True:
    pass
    