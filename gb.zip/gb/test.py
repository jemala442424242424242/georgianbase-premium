import pandas as pd
import sqlite3
import mysql.connector
import time

# db = sqlite3.connect("gb.db")
host = "127.0.0.1"
user = "root"
passwd = ""
database = "geobase"


db = mysql.connector.connect(
    host=host,
    user=user,
    passwd = passwd,
    database= database
)



kurs = db.cursor()

# while True:
#     que = input("")
#     kurs.execute(que)
#     db.commit()
#     for i in kurs.fetchall():
#         print(i)

host = "127.0.0.1"
user = "root"
passwd = ""
database = "geobase"


db = mysql.connector.connect(
    host=host,
    user=user,
    passwd = passwd,
    database= database
)

kurs = db.cursor()
x = 0

for i in range(0,900000):
    kurs.execute("INSERT INTO users(ip,mail,password,vcode,user_creation_time) VALUES('123.3123','feafeaf@gmai','efaefeaf',1,31)")
    x+=1
    print( str(int((x / 900000) * 10000) / 100) + "%" )
db.commit()
#piadi .,gvari,saxeli,mamis saxeli,sqesi,dab weli,reg TariRi,DMONAC,mocmobis .,quCa,REGMDAT
#piadi .,gvari,saxeli,mamis saxeli,sqesi,dab weli,quCa,REGMDAT
# [13, 32, 30, 30, 3, 10, 10, 3, 9, 76, 13]

# df = pd.read_csv("Georgia base.csv",on_bad_lines="skip")
# df = df.to_numpy()
# # kurs.execute("CREATE TABLE database(pir_nomeri INTEGER(13), gvari VARCHAR(32), saxeli VARCHAR(30), mama VARCHAR(30), sqesi VARCHAR(3), dabweli VARCHAR(10), qucha VARCHAR(76), reg VARCHAR(13)    ) ;")
# # kurs.execute("DELETE FROM database;")
# db.commit()
# print("gai")
# non_idnans = 0
# inserted = 0
# dflen = len(df)
# for i in df:
#     # print("gastavo",i,"call",i[0],type(i[0]))
#     print(str(int((inserted/dflen) * 10000)/100 ) + "%")
#     if str(i[0]) != "nan":
#         kurs.execute("INSERT INTO the_database(pir_nomeri,gvari,saxeli,mama,sqesi,dabweli,qucha,reg) VALUES(%s,%s,%s,%s,%s,%s,%s,%s);",(int(i[0]),str(i[1]),str(i[2]),str(i[3]),str(i[4]),str(i[5]), str(i[9]),str(i[10])  ))
#         inserted +=1
#     else:
#         non_idnans+=1
# print("success")
# print("non_idnans :",non_idnans)
# cominput = input("commit?(y / n) ")
# if cominput == "y":
#     db.commit()
# print("done")
# kurs.execute("""
# CREATE TABLE `request_infos` (
#   `id` INTEGER PRIMARY KEY AUTOINCREMENT,
#   `ip` VARCHAR(20) DEFAULT NULL,
#   `header_info` VARCHAR(1500) DEFAULT NULL,
#   `request_name` VARCHAR(50) DEFAULT NULL,
#   `request_date` VARCHAR(40) DEFAULT NULL,
#   `payload` VARCHAR(100) DEFAULT NULL,
#   `request_time` INTEGER(11) DEFAULT NULL
# )
# """ )

# db.commit()

# kurs.execute("SELECT * FROM database WHERE pir_nomeri = 24001014363;")
# kurs.execute("SELECT * FROM database WHERE pir_nomeri = :aidi;",{"aidi" :  24001014360})
# kurs.execute("SELECT * FROM request_infos;")


# print(kurs.fetchall())



# import time
# import pandas as pd
# import numpy as np
# import psutil
# first = psutil.virtual_memory()[3]
# dtype = {"piadi ." : str, "gvari" : str,"saxeli" : str,"mamis saxeli" : str,"sqesi" : float,"dab weli" : str, "reg TariRi" : str,"DMONAC" : str,"mocmobis ." : str,"quCa" : str,"REGMDAT" : str}
# df = pd.read_csv("Georgia base.csv",on_bad_lines="skip"
#                 # ,low_memory=False 
#                 # ,low_memory=True
#                 # ,dtype=dtype
#                 )

# df = df.to_numpy()
# print("done searching")
# mon = [0]*11

# for i in df:
#     x = 0
#     for e in i:
#         sig = len(str(e))
#         if mon[x] < sig:
#             mon[x] = sig

#         x+=1

# print(mon)
# [13, 32, 30, 30, 3, 10, 10, 3, 9, 76, 13]
# last = psutil.virtual_memory()[3]

# rise = (last- first)/ 100000000 #int((last-first) / 100000000) / 10

# print("rise: ",rise)

# time.sleep(999*9)