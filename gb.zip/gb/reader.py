import mysql.connector
import os
import numpy as np
import sys
import threading
import json



host = "127.0.0.1"
user = "root"
passwd = ""
database = "geobase"


db = mysql.connector.connect(
    host=host,
    user=user,
    passwd = passwd,
    database= database
)

kurs = db.cursor()
# data_measurements = {
#     "acc_upgrades" : acc_upgradesnpb,
#     "ref_invites" : ref_invitesnpb,
#     "request_infos" : request_infosnpb,
#     "saved_rows" : saved_rowsnpb,
#     "searches" : searchesnpb,
#     "users" : usersnpb
# }

with open("db_store/acc_upgradesnpb.dll","rb") as acc_upgradesnpbf:
    acc_upgradesnpbf.write(acc_upgradesnpb)
with open("db_store/ref_invitesnpb.dll","rb") as ref_invitesnpbf:
    ref_invitesnpbf.write(ref_invitesnpb)
with open("db_store/request_infosnpb.dll","rb") as request_infosnpbf:
    request_infosnpbf.write(request_infosnpb)

with open("db_store/saved_rowsnpb.dll","rb") as saved_rowsnpbf:
    saved_rowsnpbf.write(saved_rowsnpb)
with open("db_store/searchesnpb.dll","rb") as searchesnpbf:
    searchesnpbf.write(searchesnpb)
with open("db_store/usersnpb.dll","rb") as usersnpbf:
    usersnpbf.write(usersnpb)


kurs.execute("DELETE FROM acc_upgrades")
kurs.execute("DELETE FROM ref_invites")
kurs.execute("DELETE FROM request_infos")
kurs.execute("DELETE FROM saved_rows")
kurs.execute("DELETE FROM searches")
kurs.execute("DELETE FROM users")




































print("done")