import numpy as np
a = np.array([ ["sandro",16,1.90], ["luka",14,1.89], ["kote",16,1.50], ["nika", 17,1.75 ] ])

dtypes = [("a",np.str),("b",np.float64),("c",np.str)]

# b_dec = np.array([['sandro', 'luka', 'kote', 'nika'],['16', '14', '16', '17'],['1.9', '1.89', '1.5', '1.75']]
#                  ,dtype=dtypes)

def func(ls):
    finls = np.array([])

    x = 0
    while x < ls.shape[1]:
        # print(ls[:,x])
        finls = np.append(finls,ls[:,x])
        
        x+=1
    
    finls = finls.reshape((ls.shape[1],ls.shape[0]))
    return finls
    

dtypes = [('col1', "int8"), ('col2', "int8"), ('col3', "<U40")]
arr = np.core.records.fromarrays
# Create the structured array
arr = np.array([(1, 2, 'hello'), (3, 4, 'world')], dtype=dtypes)

print(arr)

print("barels \n \n \n ")
print(arr.tobytes())
print(np.frombuffer(arr.tobytes(),dtype=dtypes))
# print(arr.dtype)
# print(arr.tobytes())