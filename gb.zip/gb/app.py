
import pandas as pd
import numpy as np
from flask import Flask, render_template, request,redirect, Markup, jsonify
import datetime
from cryptography.fernet import Fernet
import json
# import mysql.connector
import sqlite3
import mysql.connector
import time
import psutil
import hashlib
import time
import random
import threading
import requests
import pyautogui
import paypalrestsdk




import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


production = False


smtp_server = 'smtp.gmail.com'
smtp_port = 587
smtp_username = 'georgianbase2023@gmail.com'
# smtp_password = 'e j j y e n v e i c g a r n q k'
smtp_password = 'odqqpejulbbofbrv'
# smtp_password = 'x q l i m w g w f l j p g h g j'



# Set up the ec_user content
from_address = 'georgianbase2023@gmail.com'


# <meta property="og:url"           content="https://sfero.ge/ka" />
#         <meta property="og:type"          content="website" />
#         <meta property="og:title"         content="{{servisebi_user_username}} : {{service_satauri}}" />
#         <meta property="og:description"   content="{{service_agwera}}" />
#         <meta property="og:image"         content="https://sfero.ge/assets/front/assets/img/fb_cover.png?v=1" />

paypalrestsdk.configure({
    "mode": "live", # sandbox or live
    # "client_id": "AbK0JoyjnjEnHzJnY5DY_fK0Db2eyghooGgU2143llwym-2PDvjs9yok0HCmv7oj-8CVn7kvJxoYeyDD",
    # "client_secret": "EMfg-CGECoMZ1rYCLOMXSgpVhl03kiVSM5g2F_Gnzds9CWqYz_UohWOowvvqmKBerisPPOH-PcV-z24d" #qotans@gmail.com

    # "client_id": "ASIqcFYJvEYNstHxX7lPXyyKseh_HmRu2XM2Mr6WV707rQC7FpAdOtEtQrsGD_RRpStN921UQyPgAuLH",
    # "client_secret": "ECbBG9YI0Dmp36PgLzXCGec7TV32SnRaE8l3NogPIq40yjbO_k4zVA5R_uTL6ospah79-k_BCaawfvQp" #georgiandbase

    # "client_id": "AZ2GD33My_4V9Ey286VbkVTlny4HkkYU-Zw3YE0Bqq2iFpKdIanwuJoDtIkBvUdR3SEvTGxQ587z6EnE",
    # "client_secret": "ECBa_9EstxzJrqFIMfDK1Ev3Cmi2HVVZQeBOMHT2kaFl7LTFRq_-F4J9nFgDtlv0erDwHuTlDFtnGuu6" #georgiandatabase16

    "client_id": "ATDKxmIiCRrDe5p2zrmC3ur5mOst171IYrCo6Y_Q4SaOPP7uqlpnwFvnHKjOnTPsoDusLFYjx1DaDy_G",
    "client_secret": "ENIgLNEHi9jq-xlLyw_ggoFTQL8SWT3FZ10FFyFAA_5RtES27O9bHGLfTrUAXuTuUKtKmjzA_vkdKQ3G" #technotok

    
    
    })


if production:

    server =  smtplib.SMTP(smtp_server, smtp_port)
    server.starttls()
    server.login(smtp_username, smtp_password)
app = Flask(__name__)

# kurs.execute("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, ip VARCHAR(30), mail VARCHAR(40), password VARCHAR(100), vcode INTEGER, user_creation_time INTEGER, refstr VARCHAR(50) )")
# kurs.execute("CREATE TABLE saved_rows(row_id INTEGER PRIMARY KEY AUTOINCREMENT, saver_id INTEGER, piradobis_nomeri_id INTEGER)")
# kurs.execute("CREATE TABLE searches(search_id INTEGER PRIMARY KEY AUTOINCREMENT, searcher_ip VARCHAR(50))")
# kurs.execute("CREATE TABLE acc_upgrades(acc_upgrade_id INTEGER PRIMARY KEY AUTOINCREMENT, upgraded_acc_id INTEGER, acc_upgrade_time INTEGER, acc_upgrade_duration INTEGER, acc_upgrades_passtype VARCHAR(40)); ")





# kurs.execute("CREATE TABLE ref_invites( ref_invite_id  INTEGER PRIMARY KEY AUTOINCREMENT, ref_inviter_id INTEGER, ref_invited_ip  VARCHAR(30) , ref_invite_status VARCHAR(2)) ;")
# 7rTCmEY8BIvy1Tg7zu96EgxthGEOOl
# 46.49.79.2

# to_address = 'sandro.letodiani@gc_user.com'

enc_keys = {}
payment_ids = {}

# host = "127.0.0.1"
# user = "root"
# passwd = ""
# database = "geobase"


# db = mysql.connector.connect(
#     host=host,
#     user=user,
#     passwd = passwd,
#     database= database
# )






continuing_searches = {}
continuing_saved_searches = {}

locations = [
        "აბასთუმანი",
        "ახალციხე",
        "ბათუმი",
        "ბაკურიანი",
        "ბოლნისი",
        "ბორჯომი",
        "გონიო",
        "გორი",
        "გუდაური",
        "გურჯაანი",
        "დავით-გარეჯი",
        "ზესტაფონი",
        "ზუგდიდი",
        "თბილისი",
        "თელავი",
        "თიანეთი",
        "ლაგოდეხი",
        "ლანჩხუთი",
        "მანგლისი",
        "მარნეული",
        "მესტია",
        "მცხეთა",
        "ოზურგეთი",
        "ომალო",
        "ონი",
        "რუსთავი",
        "საგარეჯო",
        "სამტრედია",
        "საჩხერე",
        "სენაკი",
        "სიონი",
        "სიღნაღი",
        "სოხუმი",
        "სურამი",
        "ურეკი",
        "უშგული",
        "ფოთი",
        "ქობულეთი",
        "ქუთაისი",
        "შატილი",
        "შეკვეთილი",
        "შოვი",
        "ჩოხატაური",
        "ცხინვალი",
        "წინანდალი",
        "წყნეთი",
        "ჭიათურა",
        "ხარაგაული",
        "ხაშური",
        "ხობი"
    ]
locations_en = [
        "abastumani",
        "axalcixe",
        "batumi",
        "bakuriani",
        "bolnisi",
        "borjomi",
        "gonio",
        "gori",
        "gudauri",
        "gurjaani",
        "davit gareji",
        "zestafoni",
        "zugdidi",
        "tbilisi",
        "telavi",
        "tianeti",
        "lagodexi",
        "lancxuti",
        "manglisi",
        "marneuli",
        "mestia",
        "mcxeta",
        "ozurgeti",
        "omalo",
        "oni",
        "rustavi",
        "sagarejo",
        "samtredia",
        "sacxere",
        "senaki",
        "sioni",
        "sirnari",
        "soxumi",
        "surami",
        "ureki",
        "usguli",
        "foti",
        "qobuleti",
        "qutaisi",
        "satili",
        "sekvetili",
        "sovi",
        "coxatauri",
        "cxinvali",
        "winandali",
        "wyneti",
        "wiatura",
        "xaragauli",
        "xasuri",
        "xobi"


        ]

alt_names = [
    ['Giorgi', 'Goga', 'Gia', 'Gio'],
    ['Nino','Nini', 'Niniko', 'Ninutsa','Nina'],
    ['Davit', 'Dato', 'Daviti'],
    ['Sandro','Aleqsandre'],
    ['Ana', 'Anuka', 'Anano','Ani'],
    ['Levan', 'Leko', 'Levani'],
    ['Mariam', 'Mako', 'Marika'],
    ['Irakli', 'Irako', 'Iro','Ika','Irakla'],
    ['Salome', 'Sali', 'Saliko','Salo'],
    ['Kakha', 'Kako', 'Kakhi'],
    ['Natia', 'Nati', 'Nato'],
    ['Lasha', 'Lasho', 'Lashka'],
    ['Tamar', 'Tamari', 'Tamuna'],
    ['Vakhtang', 'Vako', 'Vakho'],
    ['Nana', 'Nanuka', 'Nani'],
    ['Keti', 'Kato', 'Keti'],
    ['Daviti', 'Dato', 'Davit'],
    ['Nuka', 'Nuki', 'Nukri'],
    ['Mari', 'Mariko', 'Marita'],
    ['Revaz', 'Rezo', 'Razik'],
    ['Nata', 'Nati', 'Natia'],
    ['Malkhaz', 'Mako', 'Malkhazi'],
    ['Tekla', 'Tako', 'Teko','Tiko', 'Tika', 'Tikoza'],
    ['Shalva', 'Shako', 'Shaliko'],
    ['Shorena', 'Shoka', 'Shoni'],
    ['Temur', 'Temo', 'Temo'],
    ['Tamari', 'Tamro', 'Tamaro'],
    ['Gvantsa', 'Gvanto', 'Gva'],
    ['Erekle', 'Reko', 'Erek'],
    ['Elene', 'Leko', 'Lena','Elena','Ele'],
    ['Nikoloz', 'Nika', 'Nikusha', 'Niko'],
    ['Ekaterine', 'Eka', 'Katia', 'Kato'],
    ['Shota', 'Shako', 'Shotaia'],
    ['Nargiz', 'Nara', 'Nargo'],
    ['Lado', 'Ladiko', 'Lasha'],
    ['Sophio', 'Sofiko', 'Sofi'],
    ['Zaza', 'Zazo', 'Zauri'],
    ['Lamara', 'Lami', 'Lamz'],
    ['Archil', 'Archo', 'Archi'],
    ['Eteri', 'Eto', 'Eteriko'],
    ['Zurab', 'Zura', 'Zuro'],
    ['Rusudan', 'Rusi', 'Rusiko'],
    ['Badri', 'Bado', 'Badocha'],
    ['Tsisana', 'Tsisa', 'Tsitsi'],
    ['Zviad', 'Zviadi', 'Zvi'],
    ['Elguja', 'Elguji', 'Elgo'],
    ['Gvantsa', 'Gva', 'Gviko'],
    ['Manana', 'Mano', 'Manoni'],
    ['Ucha', 'Uchiko', 'Uchu'],
    ['Lali', 'Laliko', 'Lala'],
    ['Guram', 'Gura', 'Guga'],
    # ['Ia', 'Ika', 'Iago'],
    # ['Tiko', 'Tika', 'Tikoza'],
    ['Ketino', 'Keto', 'Keti'],
    ['Leila', 'Leilo', 'Leiloza'],
    ['Gogi', 'Gogicha', 'Gogita'],
    ['Mzia', 'Mziako', 'Mzi'],
    ['Vaso', 'Vasiko', 'Vasoza'],
    ['Gaga', 'Gagusha', 'Gagiko'],
    ['Khatuna', 'Khati', 'Khato'],
    ['Sveta',"Svetlana"],
    ['Kote',"Konstantine"],
    ["Bidzina","Bidzo"],
    ["Qristine","Qristina"],
    ["Misha","Misho","Mishka","Mikheili","Mikheil","Mixeili","Mixeil"]
]

def ranstr(zoma,charls="qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890"):
    pasuxi = ""
    chls = list(charls)
    for i in range(0,int(zoma)):
        pasuxi+= charls[random.randint(0,len(charls)-1)]
    return pasuxi

def auth(c_user,xs,tipi="cookie"):

    pasuxi = False
    if c_user != None and xs != None:
        db = sqlite3.connect("gb.db")
        kurs = db.cursor()

        

        

        kursf = kurs.fetchone()

        if tipi == "cookie":
            
            kurs.execute("SELECT * FROM users WHERE id = :id",{"id" : int(c_user) })
            kursf= kurs.fetchone()
            if kursf != None:
                if kursf[3] == hashlib.sha256(xs.encode("utf-8")).hexdigest():
                    if kursf[4] == 1:
                        pasuxi = True
                    elif kursf[4] != 1 and  int(kursf[5]) < (int(time.time()) - (10*60)):
                        pasuxi = "unverified_expired"
                    elif kursf[4] != 1 and  int(kursf[5]) > (int(time.time()) - (10*60)):
                        pasuxi = "unverified"
        elif tipi == "login":
            kurs.execute("SELECT * FROM users WHERE id = :id",{"id" : c_user })
            if kursf != None:
                if kursf[3] == hashlib.sha256(hashlib.md5(xs.encode("utf-8")).hexdigest().encode("utf-8")).hexdigest():
                    pasuxi = True
            

    return pasuxi
def premium(c_user,xs):
    db = sqlite3.connect("gb.db")
    kurs = db.cursor()
    # kurs.execute("CREATE TABLE acc_upgrades(acc_upgrade_id INTEGER PRIMARY KEY AUTOINCREMENT, upgraded_acc_id INTEGER, acc_upgrade_time INTEGER, acc_upgrade_duration INTEGER, acc_upgrades_passtype VARCHAR(40)); ")
    if auth(c_user,xs) == True:
        kurs.execute("SELECT * FROM acc_upgrades WHERE acc_upgrades_passtype = 'premium'   AND   upgraded_acc_id = :upgraded_acc_id AND  (acc_upgrade_time + acc_upgrade_duration ) > :curr_time ;",{"upgraded_acc_id" : int(c_user), "curr_time" : int(time.time())})
        if kurs.fetchall() == []:
            return False
        else:
            return True
    else:
        return False

def root_proccess(markupi):
    qveda = markupi.split("""id="root">""")[1]
    mainspl = qveda.split("</div>")
    gverdi = ""
    for i in mainspl[:len(mainspl)-2]:
        gverdi+=i
    return gverdi

def reqapprove(request,url_name,payload={}):
    
    db = sqlite3.connect("gb.db")
    ip = request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr).replace("::ffff:","")
    header = str(request.headers)

    print("bury it",request.headers.get("Content-Type"))
    if request.headers.get("Content-Type") !="application/x-www-form-urlencoded":
        if production:
                ipinfoio_url = f"https://ipinfo.io/{ip}/json"
                req = requests.get(ipinfoio_url)
                data = json.loads(req.text)
                regioni = data["country"]
                if regioni == "GE":
                    ip_gateway = True
                else:
                    ip_gateway = False
        else:
            ip_gateway = True
        if ip_gateway:
            print("yeah",ip)
            kurs = db.cursor()
            kurs.execute("SELECT * FROM request_infos WHERE ip = :aipi AND request_time > :mindro",{"aipi" : str(ip),"mindro" : int(time.time()) - 3600 })
            kursf = kurs.fetchall()
            print("amitimi",len(kursf))
            kurs.execute("INSERT INTO request_infos(ip  ,header_info    ,request_name   ,request_date   ,       payload , request_time  ) VALUES(?,?,?,?,?,?)",(ip,header,url_name,str(datetime.datetime.now()),json.dumps(payload),int(time.time()) ))
            # maxnum = 50
            maxnum = 5000000000
            
            if len(kursf) < maxnum:
                
                db.commit()
                resbool =  True
            else:
                resbool =  "too much requets"
            return {"resbool" : resbool, "ip" : ip,"kurs" : kurs}
        else:
            return "blocked_ip"
            


@app.route("/pc_stat")
def pc_stat():
    return str(psutil.sensors_battery()[0]) + "%"

@app.route("/")
def homepage():
    print("cook",request.headers.get("Content-Type"))
    reqap = reqapprove(request,"/")
    if reqap["resbool"] == True:
        # if request.args.get("type")  =="dynamic":
            
            # return root_proccess(render_template("index.html"))
        # else:
            # return render_template("index.html",bg=Markup(render_template("bg.html")))
        
        authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
        c_user = request.cookies.get("c_user")
        xs = request.cookies.get("xs")
        
        
        if authi == True:
            loggedin_bool = "true"
            db = sqlite3.connect("gb.db")
            kurs = db.cursor()
            kurs.execute("SELECT * FROM users WHERE id = :id",{"id" : int(request.cookies.get("c_user"))})
            kursf = kurs.fetchone()
            if premium(c_user,xs) == True:
                profile_info_arr_bgcolor = "#cab333"
            else:
                profile_info_arr_bgcolor = "white"
            navbar_authed = Markup(render_template("navbar_authed.html",mail=kursf[2], profile_info_arr_bgcolor=profile_info_arr_bgcolor))
            unauthed_reglog = ""
            unauthed_reglog_mob = ""
        else:
            loggedin_bool = "false"
            navbar_authed = ""
            

            unauthed_reglog = Markup("""
                    <h3 id = "registracia" class = "account_access_label">რეგისტრაცია</h3>
                    <h3 id = "avtorizacia" class = "account_access_label">ავტორიზაცია</h3>
                """)
            unauthed_reglog_mob = Markup("""
            <div id = "mobile_navbar_btn">
                <svg viewBox="0 0 100 80" width="40" height="40">
                    <rect width="100" height="20" fill = "white"></rect>
                    <rect y="30" width="100" fill="white" height="20"></rect>
                    <rect y="60" width="100" fill = "white" height="20"></rect>
                </svg>
            </div> 
                <div id = "mobile_navbar">
                    <div id = "mobile_navbar_cancell_btn"></div>
                    <h3 class = "mob_account_access_label" id ="mob_registracia">რეგისტრაცია</h3>
                    <h3 class = "mob_account_access_label" id = "mob_avtorizacia">ავტორიზაცია</h3>
                    
                </div>
            """)
        if production:
            ipinfoio_url = f"https://ipinfo.io/{reqap['ip']}/json"
            req = requests.get(ipinfoio_url)
            data = json.loads(req.text)
            regioni = data["city"]
        else:
            regioni = "tbilisi"
        if production:
            saxeli_value = ""
            gvari_value = ""
            
        else:
            saxeli_value = "ნიკა"
            gvari_value = "კაპანაძე"
        
        redirect_act_reqArg = request.args.get("redirect_act")
        
        return render_template("index.html",redirect_act_reqArg=redirect_act_reqArg,authed=str(authi),premium=str(premium(c_user,xs)),bg=Markup(render_template("bg.html")),regioni=regioni.capitalize(),saxeli_value=saxeli_value,gvari_value=gvari_value , navbar_authed=navbar_authed,unauthed_reglog=unauthed_reglog,unauthed_reglog_mob=unauthed_reglog_mob ,loggedin_bool=loggedin_bool)
        
    else:
        return reqap["resbool"]
    
@app.route('/payment', methods=['GET','POST'])
def payment():
    
    # fasi = 4.99
    authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
    c_user = request.cookies.get("c_user")
    xs = request.cookies.get("xs")
    if authi == True:
        db = sqlite3.connect("gb.db")
        kurs = db.cursor()
        if premium(c_user,xs) != True:
            if production:
                fasi = int((int(request.form["raodenoba"]) * 4.99) * 100) /100
            
            else:
                fasi = 0.01
                fasi = 0.01 * int(request.form["raodenoba"])
                
            print(fasi)
            raodenoba = 1
            # raodenoba = request.form["raodenoba"]
            print("payment POST",raodenoba)
            payment = paypalrestsdk.Payment({
                "intent": "sale",
                "payer": {
                    "payment_method": "paypal"},
                "redirect_urls": {
                    # "return_url": "http://localhost:5000/payment/execute",
                    # "cancel_url": "http://localhost:5000/"},
                    "return_url": "/payment/execute",
                    "cancel_url": "/"},
                "transactions": [{
                    "item_list": {
                        "items": [{
                            "name": "Premium",
                            "sku": "12345",
                            "price": str(fasi),
                            "currency": "USD",
                            "quantity": 1 }]},
                    "amount": {
                        "total": str(fasi),
                        "currency": "USD"},
                    "description": "This is the payment transaction description."}]})

            if payment.create():
                print('Payment success!')
            else:
                print(payment.error)
            payment_ids[str(payment.id)]  = {"c_user" : c_user, "xs" : xs, "raodenoba" : str(request.form["raodenoba"])}
            return jsonify({'paymentID' : payment.id})

@app.route('/execute', methods=['GET','POST'])
def execute():
    success = False
    authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
    myData = payment_ids[str(request.form['paymentID'])]
    c_user = request.cookies.get("c_user")
    xs = request.cookies.get("xs")

    if authi == True and myData["c_user"] == c_user and myData["xs"] == xs:
        payment = paypalrestsdk.Payment.find(request.form['paymentID'])
        print("executing!")
        payment_response = payment.execute({'payer_id' : request.form['payerID']})
        if payment_response:
            print('Execute success!',payment_response,type(payment_response))
            c_user = request.cookies.get("c_user")
            xs = request.cookies.get("xs")
            db = sqlite3.connect("gb.db")
            kurs = db.cursor()
            
            # kurs.execute("CREATE TABLE acc_upgrades(acc_upgrade_id INTEGER PRIMARY KEY AUTOINCREMENT, upgraded_acc_id INTEGER, acc_upgrade_time INTEGER, acc_upgrade_duration INTEGER, acc_upgrades_passtype VARCHAR(40)); ")
            #warmatebit gadaixada
            # db = mysql.connector.connect(
            
            #             host=sql_host,
            #             user=sql_user,
            #             passwd=sql_passwd,
            #             database=sql_db
        

            # )
            # kurs = db.cursor()

            # kurs.execute("UPDATE users SET premium_time = '"+ str(int(time.time())) +"' WHERE username = '"+c_user+"';")

            # kurs.execute("ALTER TABLE "+c_user+"_tab MODIFY text VARCHAR(5000);")


            #kurs.execute("ALTER TABLE " +c_user + "_tab DROP text")

            #kurs.execute("ALTER TABLE " +c_user + "_tab ADD text VARCHAR(5000) ")

            # db.commit()

            acc_upgrade_duration = int(time.time()) +( int(myData["raodenoba"]) * 84600 * 30)
            kurs.execute("INSERT INTO acc_upgrades(upgraded_acc_id,acc_upgrade_time,acc_upgrade_duration,acc_upgrades_passtype) VALUES(?,?,?,'premium');",(int(c_user), int(time.time()), int(acc_upgrade_duration)  ) )
            db.commit()
            success = True
            
        else:
            print(payment.error)

        return jsonify({'success' : success})


@app.route("/login",methods=["GET","POST"])
def login():
    reqap = reqapprove(request,"/login")
    if reqap["resbool"] == True:
        authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))

        if authi != True:
            if request.method == "GET":
                redirecti = request.args.get('redirect')
                return render_template("login.html",redirecti=redirecti,bg=Markup(render_template("bg.html")),navbar=Markup(render_template("navbar.html")) )
            elif request.method == "POST":
                db = sqlite3.connect("gb.db")
                kurs = db.cursor()
                mail = request.form["mail_input"]
                xs = hashlib.md5(request.form["pass_input"].encode('utf-8')).hexdigest()
                kurs.execute("SELECT * FROM users WHERE mail = '"+ mail +"' AND password = '"+ str(hashlib.sha256(xs.encode("utf-8")).hexdigest()) +"'")
                # kurs.execute("SELECT * FROM users WHERE mail = :mail AND password = :xs",{"mail" :mail,"xs" : hashlib.sha256(xs.encode("utf-8")).hexdigest() })
                kursf = kurs.fetchone()

                resbool = "false"
                msg = "არასწორი მონაცემები"
                c_user = ""
                enc_key = ""
                enc_keystr = ""


                if kursf != None:
                    c_user = str(kursf[0])
                    msg = ""
                    resbool = "true"
                    # enc_key = Fernet.generate_key()
                    # enc_keys[c_user] = enc_key
                    # enc_keystr = enc_key.decode("utf-8")
                
                return json.dumps({"resbool" : resbool,"c_user" : c_user,"xs" : xs,"msg" : msg
                                #    ,"enc_key" :enc_keystr
                                    })


@app.route("/resend_vcode",methods=["GET","POST"])
def resend_vcode():
    c_user = request.cookies.get("c_user")
    xs = request.cookies.get("xs")
    if c_user != None and xs != None:
        authi = auth(c_user,xs)
        if authi == "unverified":
            message = MIMEMultipart()
            message['From'] = from_address
            message['To'] = ""
            vcode = random.randint(100000,999999)
            db = sqlite3.connect("gb.db")
            kurs = db.cursor()
            kurs.execute("SELECT * FROM users WHERE id = :c_user ; ",{"c_user" : int(c_user)})
            kursf = kurs.fetchone()
            if kursf != None:
                mail = kursf[2]
                kurs.execute("UPDATE users SET vcode = :vcode WHERE  id =  :c_user;",{"vcode" : vcode,"c_user" : c_user})
                mailsend(mail,vcode)
                db.commit()
                # threading.Thread(target=mailsend,args=(mail,vcode)).start()
                return "success"


@app.route("/upgrade_account/<tipi>/<passi>")
def upgrade_account(tipi,passi): 
    #tipi - jerjerobit mxolod valuebi : "buy" da "referal"
    #passi - premium an tu cifri dinamikuri ogond auclieblad 3is jeradi
    reqap = reqapprove(request,"/upgrade_account")
    if reqap["resbool"] == True:
        if request.method == "GET":
            authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
            
            if authi == True:
                c_user = request.cookies.get("c_user")
                xs = request.cookies.get("xs")
                print("sama taim")
                if tipi == "buy":
                    if passi == "premium":
                        if request.cookies.get("c_user") != None or request.cookies.get("xs") != None:
                            
                            if authi == True:
                                db = sqlite3.connect("gb.db")
                                kurs = db.cursor()
                                kurs.execute("SELECT * FROM users WHERE id = :id",{"id" : int(request.cookies.get("c_user"))})
                                kursf = kurs.fetchone()
                                navbar_authed = Markup(render_template("navbar_authed.html",mail=kursf[2]))


                                return render_template("buy_premium.html",bg=Markup(render_template("bg.html")),navbar_authed=navbar_authed)
                elif tipi == "referal":
                    if passi == "premium":

                        # if premium(c_user,xs) != True:
                        db = sqlite3.connect("gb.db")
                        kurs = db.cursor()
                        kurs.execute("SELECT * FROM users WHERE id = :id",{"id" : int(request.cookies.get("c_user"))})
                        kursf_u = kurs.fetchone()
                        refstr = kursf_u[6]
                        navbar_authed = Markup(render_template("navbar_authed.html",mail=kursf_u[2]))

                        # kurs.execute("CREATE TABLE ref_invites( ref_invite_id  INTEGER PRIMARY KEY AUTOINCREMENT, ref_inviter_id INTEGER, ref_invited_ip  VARCHAR(30) , ref_invite_status VARCHAR(2)) ;")

                        if premium(c_user,xs) != True:
                            
                            

                            kurs.execute("SELECT ref_invite_id, ref_inviter_id, ref_invited_ip FROM ref_invites WHERE ref_inviter_id = :ref_inviter_id  ;",{"ref_inviter_id" : int(c_user)})

                            kursf_refinvites = kurs.fetchall()

                            kursf_refinvites_count = len(kursf_refinvites)

                            if production:
                                domeni = "http://georgianbase.pagekite.me"
                            else:
                                domeni = "http://localhost:5000"

                            # invite_linki = f"{domeni}/invite/{str(c_user)}/{refstr}"
                            invite_linki = f"{domeni}/invite/{refstr}"
                        

                        else:
                            kursf_refinvites_count = 0
                            invite_linki = ""


                            




                        


                        return render_template("referal_premium.html",bg=Markup(render_template("bg.html")),navbar_authed=navbar_authed
                                            ,invite_linki=invite_linki,kursf_refinvites_count=str(kursf_refinvites_count))


            
            else:
                print("redarkt")
                return redirect(f"/login?redirect=/upgrade_account/{tipi}/{passi}")
        
    
@app.route("/invite/<refstr>")
def invite(refstr):
    db = sqlite3.connect("gb.db")
    kurs = db.cursor()

    ip = request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr).replace("::ffff:","")
    kurs.execute("SELECT * FROM request_infos WHERE ip = :ip",{"ip" : ip})

    reqap = reqapprove(request,"/invite")
    if reqap["resbool"] == True:
        kursf=  kurs.fetchall()

        if len(kursf) == 0:


            return redirect("/")

        


@app.route("/saved_searches")
def saved_searches():
    reqap = reqapprove(request,"/saved_searches")
    if  request.args.get("continuing") != "true":
        gateway_bool = reqap["resbool"] 
    else:
        gateway_bool = True
    if gateway_bool == True:
        if request.method == "GET":
            if request.cookies.get("c_user") != None or request.cookies.get("xs") != None:
                authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
                c_user = request.cookies.get("c_user")
                xs = request.cookies.get("xs")
                if authi == True:
                    db = sqlite3.connect("gb.db")
                    kurs = db.cursor()
                    kurs.execute("SELECT * FROM users WHERE id = :id",{"id" : int(request.cookies.get("c_user"))})
                    kursf = kurs.fetchone()
                    if premium(c_user,xs) == True:
                        profile_info_arr_bgcolor = "#cab333"
                    else:
                        profile_info_arr_bgcolor = "white"
                    navbar_authed = Markup(render_template("navbar_authed.html",mail=kursf[2], profile_info_arr_bgcolor=profile_info_arr_bgcolor  ))

                    # kurs.execute("SELECT pir_nomeri , gvari , saxeli , mama , sqesi , dabweli , qucha , reg                                  FROM saved_rows INNER JOIN database ON piradobis_nomeri_id = pir_nomeri WHERE saver_id = :c_user",{"c_user" : int(c_user)})
                    # kursf = kurs.fetchall()
                    results = ""
                    geotve = ["იანვარი","თებერვალი","მარტი","აპრილი","მაისი","ივნისი","ივლისი","აგვისტო","სექტემბერი","ოქტომბერი","ნოემბერი","დეკემბერი"]
                    data = {}
                    kurs.execute("SELECT piradobis_nomeri_id,row_id  FROM saved_rows  WHERE saver_id = :c_user",{"c_user" : int(c_user)})
                    lisf = kurs.fetchall()
                    if lisf != []:
                        print("danana naaanaa nana")
                        lis = np.array(lisf)
                        ls = tuple(lis[:,0].reshape((1,len(lis[:,0])))[0])


                        if len(ls) == 1:
                            ls = "(" + str(ls[0]) + ")"
                        

                        print(ls)
                        

                        
                        

                        print("raitpleis")

                        if request.args.get("continuing") != "true": #tu chveulebriv

                            
                            kurs.execute("SELECT pir_nomeri , gvari , saxeli , mama , sqesi , dabweli , qucha , reg FROM database WHERE pir_nomeri IN "+ str(ls) +"  ;")

                            kursf = np.array(kurs.fetchall())

                            # row_primids = np.array()
                            
                            new_rows = np.array([])

                            # print(lis[:,0],'VEROHOOOOOOOOOOOOO',lis[:,0].astype(int))
                            for i in kursf:
                                # print(i[0])
                                indx = np.where(lis[:,0] == int(i[0]))
                                mwkrivis_idi = lis[indx,1]
                                # print("nhn",indx," ||| ")
                                sapendi = np.append(i,mwkrivis_idi)
                                # print("yh",i)

                                new_rows = np.append(new_rows,sapendi)
                            
                            new_rows = new_rows.reshape((  int(len(new_rows) / 9 ) , 9   ))
                            
                            searchtoken = c_user + ranstr(80)

                            # if request.args.get("reversed") == "true":
                            #     df = new_rows[np.argsort(new_rows[:,8].astype("int64") )[::] ]
                            # else:
                            #     df = new_rows[np.argsort(new_rows[:,8].astype("int64") )[::-1] ]
                            df = new_rows[np.argsort(new_rows[:,8].astype("int64") )[::-1] ]
                            continuing_saved_searches[searchtoken] = {"df" : df,"creation_time" : int(time.time())}

                            if request.args.get("reversed") == "true":
                                datafreimi = df[::-1]
                            else:
                                datafreimi = df

                            df = datafreimi[:10]
                            ixi = 0
                        else: # tu grdzeldebadi
                            searchtoken = request.args.get("searchtoken")

                            searchfromi = int(request.args.get("searchfrom"))

                            searchto = searchfromi + 10

                            ixi = searchfromi

                            print("gale",request.args.get("reversed") == "true")
                            if request.args.get("reversed") == "true":
                                datafreimi = continuing_saved_searches[searchtoken]["df"][::-1]
                            else:
                                datafreimi =   continuing_saved_searches[searchtoken]["df"]
                             
                            df = datafreimi[searchfromi:searchto]
                            # time.sleep(310000)l

                        # print("<new_rows>")
                        # for i in new_rows:
                            # print(i)
                        
                        
                        for i in df:
                            # try:
                            if True:
                                if True:
                                # if(  saxeli.lower() == i[2].lower() and (gvari.lower() == i[1].lower() or alt_gvari.lower() == i[1].lower() )    ):
                                    
                                    
                                    if str(i[0]) != "None":
                                        ixi+=1

                                        piradobis_nomeri = str(i[0]).replace(".0","")
                                        # print("found one : ",i)
                                        
                                        saxeli = i[2]
                                        gvari = i[1]
                                        
                                        if str(i[7]) != "None":
                                            regioni = i[7]
                                        else:
                                            regioni = "უცნობი"
                                        if str(i[6]) != "None":
                                            sacxovrebeli_qucha = i[6]
                                        else:
                                            sacxovrebeli_qucha = "უცნობი"

                                        if str(i[5]) != "None":
                                            dab_tarigi = str(i[5])

                                            ax_weli = int(str(datetime.datetime.now()).split("-")[0])
                                            ax_tve_i = int(str(datetime.datetime.now()).split("-")[1])
                                            ax_ricxvi_i = int(str(datetime.datetime.now()).split("-")[2].split()[0])
                                            weli = int(dab_tarigi.split(".")[2])


                                            ricxvi = int(dab_tarigi.split(".")[0])
                                            tve_i = int((dab_tarigi.split(".")[1]))
                                            tve = geotve[tve_i-1]
                                            wsxvaoba = str(ax_weli-weli)
                                            dabadebis_tarigi = f"{weli} წელი {ricxvi} {tve}"
                                            asaki = str(int((float(ax_weli) + float(ax_tve_i/12) + float(ax_ricxvi_i/365)) - ((float(weli))+ float(tve_i/12) + float(ricxvi/365))))
                                        
                                        else:
                                            asaki = "უცნობი"
                                            dabadebis_tarigi = "უცნობი"
                                        



                                        data[piradobis_nomeri] = {} #saxeligvari , sqesi, dabadeba, asaki, mama, sacxovrebeli qucha, regioni
                                        data[piradobis_nomeri]["saxeligvari"] = saxeli + " " + gvari
                                        if str(i[4]) != "None":
                                            if int(float(str(i[4]))) == 1:
                                                sqesi = "მამრობითი"
                                            elif int(float(str(i[4]))) == 2:
                                                sqesi = "მდედრობითი"
                                            
                                        else:
                                            sqesi = "უცნობი"

                                        if str(i[3]) != "None":
                                            mama = i[3] + " " + gvari
                                        else:
                                            mama = "უცნობი"
                                        data[piradobis_nomeri]["dabadebis_tarigi"] = dabadebis_tarigi
                                        data[piradobis_nomeri]["asaki"] = asaki
                                        data[piradobis_nomeri]["mama"] = mama
                                        data[piradobis_nomeri]["sacxovrebeli_qucha"] = sacxovrebeli_qucha
                                        data[piradobis_nomeri]["regioni"] = regioni
                                        data[piradobis_nomeri]["sqesi"] = sqesi




                                        data[piradobis_nomeri]["saved_bool"] = "true"
                                        # if authi == True:
                                        #     if i[8] == None:
                                        #         data[piradobis_nomeri]["saved_bool"] = "false"
                                        #     else:
                                        #         data[piradobis_nomeri]["saved_bool"] = "true"

                                        
                                        
                                        
                                        # <div id = "result_row_piradoba_{piradobis_nomeri}" class = " result_row_child">{str(i[8])}</div>
                                        # continuing_saved_searches[searchtoken]["df"]

                                        if datafreimi[::-1][0,0] == i[0]:
                                            last_row_bool = "true"
                                        else:
                                            last_row_bool = "false"

                                        
                                        if ( ("iphone"  in request.headers.get("User-Agent").lower()) or ("android"   in request.headers.get("User-Agent").lower() ) or ("blackberry"  in request.headers.get("User-Agent").lower() ) ):
                                            results+= f""" 
                                                <div last_row = "{last_row_bool}" id = "result_row_{piradobis_nomeri}" class = "result_row result_row_{str(ixi)}">

                                                    <div class = "upper_result_row">
                                                        <div id = "result_row_piradoba_{piradobis_nomeri}" class = "result_row_piradoba result_row_child">🆔{piradobis_nomeri}</div>
                                                        <div id = "result_row_regioni_{piradobis_nomeri}" class = "result_row_regioni result_row_child">📍{regioni}</div>
                                                        <div id = "result_row_asaki_{piradobis_nomeri}" class = "result_row_asaki  result_row_child">🎂{asaki}</div>
                                                    </div>

                                                    <div class = "lower_result_row">
                                                        <div id = "result_row_asaki_{piradobis_nomeri}" class = "result_row_saxeligvari  result_row_child">💳{saxeli} {gvari}</div>
                                                        <div id = "result_row_morebtn_{piradobis_nomeri}" piradobis_nomeri = "{piradobis_nomeri}" class = "result_row_morebtn  result_row_child">მეტი</div>
                                                    </div>

                                                </div>   """
                                             
                                        else:
                                            results+= f""" 
                                            <div last_row = "{last_row_bool}" id = "result_row_{piradobis_nomeri}" class = "result_row result_row_{str(ixi)}">

                                                
                                                <div id = "result_row_piradoba_{piradobis_nomeri}" class = "result_row_piradoba result_row_child">🆔{piradobis_nomeri}</div>
                                                <div id = "result_row_regioni_{piradobis_nomeri}" class = "result_row_regioni result_row_child">📍{regioni}</div>
                                                <div id = "result_row_asaki_{piradobis_nomeri}" class = "result_row_asaki  result_row_child">🎂{asaki}</div>
                                                <div id = "result_row_asaki_{piradobis_nomeri}" class = "result_row_saxeligvari  result_row_child">💳{saxeli} {gvari}</div>
                                                
                                                <div id = "result_row_morebtn_{piradobis_nomeri}" piradobis_nomeri = "{piradobis_nomeri}" class = "result_row_morebtn  result_row_child">მეტი</div>
                                                

                                            </div>   """
                                            
                            # except Exception as e:
                                # print("er",e)
                    else:
                        searchtoken = c_user + ranstr(80)
                        results = Markup("""
                            
                            <span id = "no_saved_persons_heading">თქვენ არ გყავთ არცერთი პიროვნება შენახული</span>

                            <div id = "modzebna_redirect">მოძებნა</div>

                        """)
                    print("quqing")
                    if request.args.get("continuing") != "true":
                        return render_template("saved_searches.html",searchtoken=searchtoken,bg=Markup(render_template("bg.html")),data=Markup(json.dumps(data)),navbar=Markup(render_template("navbar.html")),navbar_authed=navbar_authed,results=Markup(results))
                    else:
                        print("gedaun",results,data)
                        return json.dumps([results,data])
@app.route("/save_search",methods=["POST","DELETE"])
def save_search():
    reqap = reqapprove(request,"/save_search")
    if reqap["resbool"] == True:
        # if request.method == "GET":

        if request.cookies.get("c_user") != None or request.cookies.get("xs") != None:

            c_user = request.cookies.get("c_user")
            xs = request.cookies.get("xs")

            authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
            c_user = request.cookies.get("c_user")
            xs = request.cookies.get("xs")
            if authi == True:
                db = sqlite3.connect("gb.db")
                kurs = db.cursor()

                piradobis_nomeri = int(request.form["piradobis_nomeri"])
                if request.method == "POST":
                    kurs.execute("SELECT * FROM saved_rows WHERE saver_id = :saver_id AND piradobis_nomeri_id= :piradobis_nomeri;",{"saver_id" : int(request.cookies.get("c_user")), "piradobis_nomeri" : piradobis_nomeri})
                    
                    kursf = kurs.fetchall()


                    if len(kursf) == 0:   
                        kurs.execute("INSERT INTO saved_rows(saver_id,piradobis_nomeri_id) VALUES(?,?);",(c_user , piradobis_nomeri ))
                        db.commit()
                        return "success"
                if request.method == "DELETE":
                    kurs.execute("DELETE FROM saved_rows WHERE piradobis_nomeri_id = :piradobis_nomeri and saver_id = :saver_id;",{"piradobis_nomeri" : piradobis_nomeri,"saver_id" :int(request.cookies.get("c_user")) })
                    db.commit()

                    return "success"




@app.route("/confirmation",methods=["GET","POST"])
def confirmation():
    reqap = reqapprove(request,"/confirmation")
    print(reqap)
    if reqap["resbool"] == True:
        if request.method == "GET":
            print("haldaefaefoiajenfoiaenfs")
            if request.cookies.get("c_user") != None or request.cookies.get("xs") != None:
                authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
                c_user = request.cookies.get("c_user")
                xs = request.cookies.get("xs")
                print("sebozo",authi)
                # if authi == "unverified_expired":
                #     defaultcont = Markup("""
                #         <h1 id ="heading">მეილის ვერიფიცირების დრო ამოიწურა</h1>
                #         <div id = "nosymbol">
                        
                #         </div>
                #     """)
                if authi == "unverified":
                # elif authi == "unverified":
                    db = sqlite3.connect("gb.db")
                    kurs = db.cursor()
                    kurs.execute("SELECT * FROM users WHERE id = :id;",{"id" : c_user})
                    kursf = kurs.fetchone()
                    
                    defaultcont = Markup("""
                        <h1 id ="heading">მეილის ვერიფიკაცია</h1>
                        <p id = "agwera">"""+ str(kursf[2]) +""" - ზე წარმატებით გამოიგზავნა 6 ნიშნა კოდი</p><br>
                        <input id = "vcode_input" placeholder="6 ნიშნა კოდი" type="number"><br>
                        <div id  ="vcode_manage_div">
                            <div id = "resend_vcode">თავიდან გაგზავნა</div>
                            <div id = "submit">დადასტურება</div>
                        </div>
                    """)
                elif authi == True:
                    defaultcont = Markup("""
                        <h1 id ="heading">მეილი ვერიფიცირებულია</h1>
                        <div id = "checkmark">
                        
                        </div>
                    """)
                    
                else:
                    return redirect("/")
                
                return render_template("confirmation.html",maincont=defaultcont,bg=Markup(render_template("bg.html")),navbar=Markup(render_template("navbar.html")) )
            else:
                return redirect("/signup")
        elif request.method == "POST":
            print("aputata")
            if request.cookies.get("c_user") != None or request.cookies.get("xs") != None:
                authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
                c_user = request.cookies.get("c_user")
                xs = request.cookies.get("xs")
                print("auzibauzi",authi)
                if authi == "unverified" or authi == "unverified_expired":
                    input_vcode = request.form["vcode"]
                    db = sqlite3.connect("gb.db")
                    kurs = db.cursor()
                    kurs.execute("SELECT vcode, user_creation_time FROM users WHERE id = :id",{"id" : int(c_user)})
                    kursf= kurs.fetchone()
                    print("wasted",kursf)
                    if kursf != None:
                        print(int(kursf[0]) == int(input_vcode))
                        print(((  int(kursf[1]) + (60*10) ) > int(time.time()) ) ,(int(kursf[1]) + (60*10)) < (int(time.time()) )  )
                        if int(kursf[0]) == int(input_vcode) and ((  int(kursf[1]) + (60*10) ) > int(time.time()) ) :
                            result =  "success"
                            kurs.execute("UPDATE users SET vcode = 1 WHERE id = :id",{"id" : c_user})
                            db.commit()
                        elif  (int(kursf[1]) + (60*10)) < (int(time.time()) ):
                            print("tutururu")
                            result =  "ვერიფიკაციის დრო ამოიწურა"
                        elif int(kursf[0]) != int(input_vcode):
                            result =  "არასწორი კოდი"
                        
                        return json.dumps({"result" : result})

                        #i[1] > aefaefa and vcode == vcode
                        # if kursf[1] > 
                    # actual_vcode = 



def mailsend(mail,vcode):
    message = MIMEMultipart()
    message['From'] = from_address
    message['To'] = ""
    body = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>GeorgianBase მეილის ვერიფიკაცია</title>
            <style>
                #maindiv{
                    position:relative;
                    background-color:black;
                    color:white;
                    text-align:center;
                    width:60%;
                    height:325px;
                    left:50%;
                    top:50%;
                    transform:translate(-50%,-50%);
                    

                }
                #vcode{
                    position:relative;
                    left:50%;
                    transform:translate(-50%,0);
                    color:red;
                    font-size:40px;
                }
                hr{
                    backgorund-color:white;
                    color:white;
                }
                p{
                    padding: 22px;
                    font-size: 25px;
                }
                .highlight{
                    color:red;
                }
            </style>
        </head>
        <body>
        <center><h1>მეილის ვერიფიკაცია <span class = "highlight">GeorgianBase</span></h1></center><br>
        <center>
            <div id = "maindiv">
            <p>დააკოპირეთ 6 ნიშნა კოდი და ჩასვით GeorgiaBase-ის Confirmation გვერდზე</p>
            <hr>
            <h2 id = "vcode">
                """+ str(vcode)  +"""
            </h2>
                
            </div>
        </center>
            
        </body>
        </html>
    """
    
    message['Subject'] = "GeorgianBase მეილის ვერიფიკაცია"
    message.attach(MIMEText(body, 'html'))
    text = message.as_string()
    
    try:
        server.sendmail(from_address,mail , text)
    except:
        print("relogginginig")
        server =  smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(smtp_username, smtp_password)
        server.sendmail(from_address,mail , text)

    


@app.route("/signup",methods=["GET","POST"])
def signup():
    reqap = reqapprove(request,"/signup")
    if reqap["resbool"] == True:
        if request.method == "GET":
            if request.cookies.get("c_user") != None or request.cookies.get("xs") != None:
                authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
                if authi != True:
                    print("bfraef",authi)
                    return render_template("signup.html",bg=Markup(render_template("bg.html")),navbar=Markup(render_template("navbar.html")) )
                else:
                    return redirect("/")
            else:
                # return "faefaefaefeaf"
                return render_template("signup.html",bg=Markup(render_template("bg.html")),navbar=Markup(render_template("navbar.html")) )
        elif request.method == "POST":
            db = sqlite3.connect("gb.db")
            kurs = db.cursor()
            resbool = "false"
            eror_msg = ""
            mail = request.form["mail"]
            xs = ""
            c_user = ""
            kurs.execute("SELECT * FROM users WHERE mail = :mail and vcode = 1",{"mail" : mail})
            kursf = kurs.fetchall()

            print("tttt",kursf)
            if kursf == []:
                if len(mail) > 0 and ("@" in mail) == True and len(mail) <= 40  and len(request.form["xs"]) <= 100:
                    if len(request.form["xs"]) > 8:
                        
                        xs = hashlib.md5(request.form["xs"].encode("utf-8")).hexdigest()

                        

                        ip = reqap["ip"] #request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr)
                        vcode = random.randint(100000,999999)
                        kurs.execute("INSERT INTO users(ip,mail,password,vcode,user_creation_time,refstr) VALUES(?,?,?,?,?,?)",(ip,mail,hashlib.sha256(xs.encode("utf-8")).hexdigest(),vcode,int(time.time()), ranstr(50) ))
                        
                        db.commit()
                        c_user = kurs.lastrowid
                        resbool = "true"
                        threading.Thread(target=mailsend,args=(mail,vcode)).start()
                        
            else:
                eror_msg = "მეილი დაკავებულია"
                
        
        return json.dumps({"resbool" : resbool,"c_user" : c_user, "xs" : xs,"eror_msg" : eror_msg})


def saxelis_shiflacia(txt):
    georgian_alphabet = {
    "ა": "a",
    "ბ": "b",
    "გ": "g",
    "დ": "d",
    "ე": "e",
    "ვ": "v",
    "ზ": "z",
    "თ": "t",
    "ი": "i",
    "კ": "k",
    "ლ": "l",
    "მ": "m",
    "ნ": "n",
    "ო": "o",
    "პ": "p",
    "ჟ": "j",
    "რ": "r",
    "ს": "s",
    "ტ": "t",
    "უ": "u",
    "ფ": "f",
    "ქ": "q",
    "ღ": "R",
    "ყ": "y",
    "შ": "S",
    "ჩ": "C",
    "ც": "c",
    "ძ": "Z",
    "წ": "w",
    "ჭ": "W",
    "ხ": "x",
    "ჯ": "j",
    "ჰ": "h"
    }
    texti = txt
    for i in georgian_alphabet:
        texti = texti.replace(i,georgian_alphabet[i])
    return texti.strip().lower()

def saxelis_damushaveba(saxeli_src):
    return saxelis_shiflacia(saxeli_src.strip().lower()).replace("chk","wy").replace("ch","c").replace("dz","z").replace("kh","x").replace("sh","s").replace("gh","r")



@app.route("/search_data",methods=["GET","POST"])
def search_data():
    payload = {}
    for i in request.form:
        payload[i] = request.form[i]
    searchtype = request.form["searchtype"]
    reqap = reqapprove(request,"/search_data",payload=payload)
    if  searchtype == "import":
        gateway_bool = reqap["resbool"] 
    else:
        gateway_bool = True
    if gateway_bool == True:
        db = sqlite3.connect("gb.db")
        kurs = db.cursor()

        # kurs.execute("SELECT * FROM request_infos WHERE request_name= '/search_data' AND ip = :ip ;",{"ip" : reqap["ip"]})
        kurs.execute("SELECT * FROM searches WHERE  searcher_ip = :ip ;",{"ip" : reqap["ip"]})
        
        modzebnis_raodenoba = len(kurs.fetchall())
        darchenili_modzebnis_raodenoba = 5 - modzebnis_raodenoba

        c_user = request.cookies.get("c_user")
        xs = request.cookies.get("xs")
        premiumi = premium(c_user,xs)
        if darchenili_modzebnis_raodenoba > 0 or searchtype == "add" or premiumi:

            if searchtype == "import":
                print("vaivudai",reqap["ip"] )
                kurs.execute("INSERT INTO searches(searcher_ip) VALUES(:ip)",{"ip" :    str(reqap["ip"])    } )
                db.commit()

            darcha_modzebnis_raodenoba = darchenili_modzebnis_raodenoba - 1
            search_data_query_ls = []

            print(type(request.headers.get("Content-Type")),"lemeteliuisfam",request.headers.get("Content-Type"))
            user_agent = request.headers.get("User-Agent")
            print("trast",request.form)


            

            if request.form["region_datatype"] == "ind":
                region = locations_en[int(request.form["region"])]
            elif request.form["region_datatype"] == "ind_en":
                region = locations_en[int(request.form["region"])]
            elif request.form["region_datatype"] == "txt":
                region = request.form["region"].strip()
            
            print("womafeafaefaef",region)
            if region == "ყველა" or region == "":
                region_query = ""
            else:
                region_query = " AND (lower(qucha) LIKE '%"+ region +"%'  OR lower(reg) LIKE '%"+  region  +"%') "
            print("ahh",region_query)

            # if request.cookies.get("c_user") != None:
            if False:
                key =  enc_keys[request.cookies.get("enc_key").decode("utf-8")] #request.cookies.get("enc_key").encode("utf-8")
                fernet = Fernet(key)
                # print(user_agent.split()[1].split(";")[1])
                saxeli_src = fernet.decrypt(request.form["saxeli"].encode("utf-8")).decode("utf-8")
                gvari_src = fernet.decrypt(request.form["gvari"].encode("utf-8")).decode("utf-8")
                alt_gvari_src = fernet.decrypt(request.form["gvari"].encode("utf-8")).decode("utf-8")
            else:
                saxeli_src = request.form["saxeli"]
                gvari_src = request.form["gvari"]
                alt_gvari_src = request.form["gvari"]
            

            
            outer_break = False
            alt_names_suggs = []
            for i in alt_names:
                for name in i:
                    if saxelis_damushaveba(name) == saxelis_damushaveba(saxeli_src):
                        alt_names_suggs = i
                        outer_break = True
                        break
                
                if outer_break:
                    break
            
            saxeli = saxelis_damushaveba(saxeli_src) #saxeli_src.lower().replace("chk","wy").replace("ch","c").replace("dz","z").replace("kh","x").replace("sh","s")
            gvari = saxelis_shiflacia(gvari_src).lower().replace("chk","wy").replace("ch","c").replace("dz","z").replace("kh","x").replace("sh","s")
            alt_gvari = saxelis_shiflacia(alt_gvari_src).lower().replace("chk","wy").replace("ch","w").replace("dz","z").replace("kh","x").replace("sh","s")
            platform = request.form["platform"]

            if alt_names_suggs == []:
                # saxeli_queri = " lower(saxeli) = :saxeli "
                saxeli_queri = " lower(saxeli) = ? "
                

                search_data_query_ls += [saxeli]
            else:
                saxeli_queri = ""


                

                search_data_query_ls+= list(map(lambda x: x.lower() ,alt_names_suggs))
                alt_names_suggs = tuple(map(lambda x :  "?" ,alt_names_suggs))
                alt_names_suggs = str(tuple(alt_names_suggs)).replace('"','').replace("'","")
                saxeli_queri+=  (" lower(saxeli)  IN  "+ alt_names_suggs +" ")

                
                # for i in alt_names_suggs:
                #     saxeli_queri+=  (" lower(saxeli) =  '" + saxelis_damushaveba( i) + "' OR ")
                # saxeli_queri+= " 1=2"



            
            results = ""
            geotve = ["იანვარი","თებერვალი","მარტი","აპრილი","მაისი","ივნისი","ივლისი","აგვისტო","სექტემბერი","ოქტომბერი","ნოემბერი","დეკემბერი"]
            data = {}

            authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
            


            additional_query_data = ""
            additional_param_data = ""
            additional_where_data = ""
            if authi == True:
                additional_query_data += " LEFT JOIN saved_rows ON pir_nomeri = piradobis_nomeri_id "
                additional_param_data += ", saver_id "
                # additional_where_data += " AND ( saver_id = "+ str(request.cookies.get("c_user")) +" OR saver_id IS NULL ) "
                additional_where_data += " AND ( saver_id = ? OR saver_id IS NULL ) "
                
            ixi = 0

            searchtoken = request.form["searchtoken"]

            min_asaki = int(request.form["min_asaki"].strip())
            max_asaki = int(request.form["max_asaki"].strip())

            def search_data_asakfilter(x):
                if str(x[5]) != "None":
                    dab_tarigi = str(x[5])

                    ax_weli = int(str(datetime.datetime.now()).split("-")[0])
                    ax_tve_i = int(str(datetime.datetime.now()).split("-")[1])
                    ax_ricxvi_i = int(str(datetime.datetime.now()).split("-")[2].split()[0])
                    weli = int(dab_tarigi.split(".")[2])


                    ricxvi = int(dab_tarigi.split(".")[0])
                    tve_i = int((dab_tarigi.split(".")[1]))
                    tve = geotve[tve_i-1]
                    wsxvaoba = str(ax_weli-weli)
                    dabadebis_tarigi = f"{weli} წელი {ricxvi} {tve}"
                    asaki = int(int((float(ax_weli) + float(ax_tve_i/12) + float(ax_ricxvi_i/365)) - ((float(weli))+ float(tve_i/12) + float(ricxvi/365))))
                    if asaki >= min_asaki and asaki <= max_asaki:
                        return True
                    else:
                        return False
                else:
                    return True

            

            # search_data_query_ls += [gvari,alt_gvari,str(request.cookies.get("c_user"))]
            search_data_query_ls += [gvari,alt_gvari]
            

            if authi == True:
                search_data_query_ls+= [str(request.cookies.get("c_user"))]
            if  searchtype == "import":
                kurs.execute(
                            # "SELECT pir_nomeri , gvari , saxeli , mama , sqesi , dabweli , qucha , reg  "+ additional_param_data +"  FROM database "+ additional_query_data +"   WHERE     ( ("+ saxeli_queri  +") AND (lower(gvari) = :gvari OR lower(gvari) = :alt_gvari ) "+ region_query +"  ) "+ additional_where_data +"   ;"
                            "SELECT pir_nomeri , gvari , saxeli , mama , sqesi , dabweli , qucha , reg  "+ additional_param_data +"  FROM database "+ additional_query_data +"   WHERE     ( ("+ saxeli_queri  +") AND (lower(gvari) = ? OR lower(gvari) = ? ) "+ region_query +"  ) "+ additional_where_data +"   ;"
                            
                            # ,{"saxeli" : saxeli,"gvari" : gvari, "alt_gvari" : alt_gvari,"c_user" : str(request.cookies.get("c_user"))}
                            ,tuple(search_data_query_ls)
                            
                            )
                df = np.array(kurs.fetchall())
                df = np.array(list(filter(search_data_asakfilter,df)))
                

                pirovnebata_raodenoba = str(len(df))
                continuing_searches[searchtoken] = {"df" : df,"creation_time" : int(time.time()) }

                datafreimi = df
                df = df[:10]
                
            elif searchtype == "add":

                # time.sleep(3)
                pirovnebata_raodenoba = 0

                fromi = int(request.form["searchtype_from"])
                to = fromi + 10
                datafreimi = continuing_searches[searchtoken]["df"]
                df = datafreimi[fromi:to]
                ixi = fromi
            




                

            
            for i in df:
                try:
                    if True:
                    # if(  saxeli.lower() == i[2].lower() and (gvari.lower() == i[1].lower() or alt_gvari.lower() == i[1].lower() )    ):
                        
                        
                        if str(i[0]) != "None":

                            ixi+=1

                            piradobis_nomeri = str(i[0]).replace(".0","")

                            
                            
                            if str(i[7]) != "None":
                                regioni = i[7]
                            else:
                                regioni = "უცნობი"
                            if str(i[6]) != "None":
                                sacxovrebeli_qucha = i[6]
                            else:
                                sacxovrebeli_qucha = "უცნობი"

                            if str(i[5]) != "None":
                                dab_tarigi = str(i[5])

                                ax_weli = int(str(datetime.datetime.now()).split("-")[0])
                                ax_tve_i = int(str(datetime.datetime.now()).split("-")[1])
                                ax_ricxvi_i = int(str(datetime.datetime.now()).split("-")[2].split()[0])
                                weli = int(dab_tarigi.split(".")[2])


                                ricxvi = int(dab_tarigi.split(".")[0])
                                tve_i = int((dab_tarigi.split(".")[1]))
                                tve = geotve[tve_i-1]
                                wsxvaoba = str(ax_weli-weli)
                                dabadebis_tarigi = f"{weli} წელი {ricxvi} {tve}"
                                asaki = str(int((float(ax_weli) + float(ax_tve_i/12) + float(ax_ricxvi_i/365)) - ((float(weli))+ float(tve_i/12) + float(ricxvi/365))))
                            
                            else:
                                asaki = "უცნობი"
                                dabadebis_tarigi = "უცნობი"
                            



                            data[piradobis_nomeri] = {} #saxeligvari , sqesi, dabadeba, asaki, mama, sacxovrebeli qucha, regioni
                            data[piradobis_nomeri]["saxeligvari"] = saxeli + " " + gvari
                            if str(i[4]) != "None":
                                if int(float(str(i[4]))) == 1:
                                    sqesi = "მამრობითი"
                                elif int(float(str(i[4]))) == 2:
                                    sqesi = "მდედრობითი"
                                
                            else:
                                sqesi = "უცნობი"

                            if str(i[3]) != "None":
                                mama = i[3] + " " + gvari
                            else:
                                mama = "უცნობი"

                            data[piradobis_nomeri]["dabadebis_tarigi"] = dabadebis_tarigi
                            data[piradobis_nomeri]["asaki"] = asaki
                            data[piradobis_nomeri]["mama"] = mama
                            data[piradobis_nomeri]["sacxovrebeli_qucha"] = sacxovrebeli_qucha
                            data[piradobis_nomeri]["regioni"] = regioni
                            data[piradobis_nomeri]["sqesi"] = sqesi

                            if authi == True:
                                if i[8] == None:
                                    data[piradobis_nomeri]["saved_bool"] = "false"
                                else:
                                    data[piradobis_nomeri]["saved_bool"] = "true"

                            
                            if piradobis_nomeri == str(datafreimi[::-1][0,0]):
                                last_row = "true"
                            else:
                                last_row = "false"
                            
                            data[piradobis_nomeri]["last_row"] = last_row
                            
                            results+= f""" <div id = "result_row_{piradobis_nomeri}" last_row = "{last_row}" class = "result_row result_row_{str(ixi)}">
                                <div id = "result_row_piradoba_{piradobis_nomeri}" class = "result_row_piradoba result_row_child">🆔{piradobis_nomeri}</div>
                                <div id = "result_row_regioni_{piradobis_nomeri}" class = "result_row_regioni result_row_child">📍{regioni}</div>
                                <div id = "result_row_asaki_{piradobis_nomeri}" class = "result_row_asaki  result_row_child">🎂{asaki}</div>
                                <div id = "result_row_morebtn_{piradobis_nomeri}" piradobis_nomeri = "{piradobis_nomeri}" class = "result_row_morebtn  result_row_child">მეტი</div>
                                

                            </div>   """
                            
                except Exception as e:
                    print("erori",e,i)


            if results == "":
                # return "notfound"
                return json.dumps(["notfound",darcha_modzebnis_raodenoba])
            else:
                return json.dumps([results,data,pirovnebata_raodenoba,darcha_modzebnis_raodenoba])
        else:
            return "no_more_free_searches"
    else:
        return reqap["resbool"]

@app.route("/admin")
def admin():
    pass

@app.route("/admin_login")
def admin_login():
    pass

@app.route("/admin_credit")
def admin_credit():
    pass

if production:
    porti = 80
else:
    porti = 5000

if __name__ == "__main__":
    app.run(debug=False,host="0.0.0.0",port=porti)