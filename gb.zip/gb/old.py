import pandas as pd
import numpy as np
from flask import Flask, render_template, request
import datetime
import json
import mysql.connector
import time
import psutil

host = "127.0.0.1"
user = "root"
passwd = ""
database = "geobase"


db = mysql.connector.connect(
    host=host,
    user=user,
    passwd = passwd,
    database= database
)


df = pd.read_csv("Georgia base.csv",on_bad_lines="skip",low_memory=False)

df = df.to_numpy()[1:]

app = Flask(__name__)


def reqapprove(request,url_name,payload={}):
    print(request.headers)
    ip = "127.0.0.1"
    header = str(request.headers)
    kurs = db.cursor()
    kurs.execute("SELECT * FROM request_infos WHERE ip = %(aipi)s AND request_time > %(mindro)s;",{"aipi" : ip,"mindro" : int(time.time()) - 3600 })
    kursf = kurs.fetchall()
    print("amitimi",len(kursf))
    kurs.execute("INSERT INTO request_infos(ip	,header_info	,request_name	,request_date	,	payload , request_time	) VALUES(%s,%s,%s,%s,%s,%s)",(ip,header,url_name,str(datetime.datetime.now()),json.dumps(payload),int(time.time()) ))
    if len(kursf) < 50:
        
        db.commit()
        return True
    else:
        return "too much requets"

@app.route("/pc_stat")
def pc_stat():
    return str(psutil.sensors_battery()[0]) + "%"

@app.route("/")
def homepage():
    reqap = reqapprove(request,"/")
    if reqap == True:
        return render_template("index.html")
    else:
        return reqap
@app.route("/search_data",methods=["GET","POST"])
def search_data():
    payload = {}
    for i in request.form:
        payload[i] = request.form[i]
    reqap = reqapprove(request,"/search_data",payload=payload)
    if reqap == True:
        user_agent = request.headers.get("User-Agent")
        print(user_agent)
        print(user_agent.split()[2])
        # print(user_agent.split()[1].split(";")[1])
        saxeli = request.form["saxeli"].lower().replace("chk","wy").replace("ch","c").replace("dz","z").replace("kh","x").replace("sh","s")
        gvari = request.form["gvari"].lower().replace("chk","wy").replace("ch","c").replace("dz","z").replace("kh","x").replace("sh","s")
        alt_gvari = request.form["gvari"].lower().replace("chk","wy").replace("ch","w").replace("dz","z").replace("kh","x").replace("sh","s")
        platform = request.form["platform"]
        
        results = ""
        geotve = ["იანვარი","თებერვალი","მარტი","აპრილი","მაისი","ივნისი","ივლისი","აგვისტო","სექტემბერი","ოქტომბერი","ნოემბერი","დეკემბერი"]
        data = {}
        for i in df:
            try:
                if(  saxeli.lower() == i[2].lower() and (gvari.lower() == i[1].lower() or alt_gvari.lower() == i[1].lower() )    ):
                    
                    
                    if str(i[0]) != "nan":
                        piradobis_nomeri = str(i[0]).replace(".0","")
                        # print("found one : ",i)
                        
                        if str(i[10]) != "nan":
                            regioni = i[10]
                        else:
                            regioni = "უცნობი"
                        if str(i[9]) != "nan":
                            sacxovrebeli_qucha = i[9]
                        else:
                            sacxovrebeli_qucha = "უცნობი"

                        if str(i[5]) != "nan":
                            dab_tarigi = str(i[5])

                            ax_weli = int(str(datetime.datetime.now()).split("-")[0])
                            ax_tve_i = int(str(datetime.datetime.now()).split("-")[1])
                            ax_ricxvi_i = int(str(datetime.datetime.now()).split("-")[2].split()[0])
                            weli = int(dab_tarigi.split(".")[2])


                            ricxvi = int(dab_tarigi.split(".")[0])
                            tve_i = int((dab_tarigi.split(".")[1]))
                            tve = geotve[tve_i-1]
                            wsxvaoba = str(ax_weli-weli)
                            dabadebis_tarigi = f"{weli} წელი {ricxvi} {tve}"
                            asaki = str(int((float(ax_weli) + float(ax_tve_i/12) + float(ax_ricxvi_i/365)) - ((float(weli))+ float(tve_i/12) + float(ricxvi/365))))
                        
                        else:
                            asaki = "უცნობი"
                            dabadebis_tarigi = "უცნობი"
                        



                        data[piradobis_nomeri] = {} #saxeligvari , sqesi, dabadeba, asaki, mama, sacxovrebeli qucha, regioni
                        data[piradobis_nomeri]["saxeligvari"] = saxeli + " " + gvari
                        if str(i[4]) != "nan":
                            if int(float(str(i[4]))) == 1:
                                sqesi = "მამრობითი"
                            elif int(float(str(i[4]))) == 2:
                                sqesi = "მდედრობითი"
                            
                        else:
                            sqesi = "უცნობი"

                        data[piradobis_nomeri]["dabadebis_tarigi"] = dabadebis_tarigi
                        data[piradobis_nomeri]["asaki"] = asaki
                        data[piradobis_nomeri]["mama"] = i[3] + " " + gvari
                        data[piradobis_nomeri]["sacxovrebeli_qucha"] = sacxovrebeli_qucha
                        data[piradobis_nomeri]["regioni"] = regioni
                        data[piradobis_nomeri]["sqesi"] = sqesi
                        
                        
                        
                        
                        results+= f""" <div id = "result_row_{piradobis_nomeri}" class = "result_row">
                            <div id = "result_row_piradoba_{piradobis_nomeri}" class = "result_row_piradoba result_row_child">{piradobis_nomeri}</div>
                            <div id = "result_row_regioni_{piradobis_nomeri}" class = "result_row_regioni result_row_child">{regioni}</div>
                            <div id = "result_row_asaki_{piradobis_nomeri}" class = "result_row_asaki  result_row_child">{asaki}</div>
                            <div id = "result_row_morebtn_{piradobis_nomeri}" piradobis_nomeri = "{piradobis_nomeri}" class = "result_row_morebtn  result_row_child">მეტი</div>
                            

                        </div>   """
            except Exception as e:
                pass

        print("search finished")
        if results == "":

            return "notfound"
        else:
            return json.dumps([results,data])
    else:
        return reqap

@app.route("/admin")
def admin():
    pass

@app.route("/admin_login")
def admin_login():
    pass

@app.route("/admin_credit")
def admin_credit():
    pass



if __name__ == "__main__":
    app.run(debug=False,host="0.0.0.0",port=5000)