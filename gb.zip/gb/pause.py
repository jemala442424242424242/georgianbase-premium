from flask import Flask, render_template, request, Markup
import mysql.connector
import random
import hashlib
import time

app = Flask(__name__)


host = "127.0.0.1"
user = "root"
passwd = ""
database = "geobase"


db = mysql.connector.connect(
    host=host,
    user=user,
    passwd = passwd,
    database= database
)


production = True


class sqlite3:
    def connect():
        db = mysql.connector.connect(
            host=host,
            user=user,
            passwd = passwd,
            database= database
        )
        return db

def ranstr(zoma,charls="qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890"):
    pasuxi = ""
    chls = list(charls)
    for i in range(0,int(zoma)):
        pasuxi+= charls[random.randint(0,len(charls)-1)]
    return pasuxi

def auth(c_user,xs,tipi="cookie"):

    pasuxi = False
    if c_user != None and xs != None:
        db = sqlite3.connect()
        kurs = db.cursor()

        

        

        # kursf = kurs.fetchone()
        print("to a man",tipi)
        if tipi == "cookie":
            
            kurs.execute("SELECT * FROM users WHERE id = %(id)s",{"id" : int(c_user) })
            kursf= kurs.fetchone()
            if kursf != None:
                if kursf[3] == hashlib.sha256(xs.encode("utf-8")).hexdigest():
                    if kursf[4] == 1:
                        pasuxi = True
                    elif kursf[4] != 1 and  int(kursf[5]) < (int(time.time()) - (10*60)):
                        pasuxi = "unverified_expired"
                    elif kursf[4] != 1 and  int(kursf[5]) > (int(time.time()) - (10*60)):
                        pasuxi = "unverified"
        elif tipi == "login":
            kurs.execute("SELECT * FROM users WHERE id = %(id)s",{"id" : c_user })
            if kursf != None:
                if kursf[3] == hashlib.sha256(hashlib.md5(xs.encode("utf-8")).hexdigest().encode("utf-8")).hexdigest():
                    pasuxi = True
    print("mei")
            

    return pasuxi
def premium(c_user,xs):
    db = sqlite3.connect()
    kurs = db.cursor()
    # kurs.execute("CREATE TABLE acc_upgrades(acc_upgrade_id INTEGER PRIMARY KEY AUTOINCREMENT, upgraded_acc_id INTEGER, acc_upgrade_time INTEGER, acc_upgrade_duration INTEGER, acc_upgrades_passtype VARCHAR(40)); ")
    if auth(c_user,xs) == True:
        kurs.execute("SELECT * FROM acc_upgrades WHERE acc_upgrades_passtype = 'premium'   AND   upgraded_acc_id = %(upgraded_acc_id)s AND  (acc_upgrade_time + acc_upgrade_duration ) > %(curr_time)s ;",{"upgraded_acc_id" : int(c_user), "curr_time" : int(time.time())})
        if kurs.fetchall() == []:
            return False
        else:
            return True
    else:
        return False

def root_proccess(markupi):
    qveda = markupi.split("""id="root">""")[1]
    mainspl = qveda.split("</div>")
    gverdi = ""
    for i in mainspl[:len(mainspl)-2]:
        gverdi+=i
    return gverdi

def reqapprove(request,url_name,payload={}):
    resbool = True
    ip = request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr).replace("::ffff:","")
    return {"resbool" : resbool, "ip" : ip}
    # db = sqlite3.connect()
    # ip = request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr).replace("::ffff:","")
    # header = str(request.headers)

    # print("bury it",request.headers.get("Content-Type"))
    # if request.headers.get("Content-Type") !="application/x-www-form-urlencoded":
    #     if production:
    #             ipinfoio_url = f"https://ipinfo.io/{ip}/json"
    #             req = requests.get(ipinfoio_url)
    #             data = json.loads(req.text)
    #             regioni = data["country"]
    #             if regioni == "GE":
    #                 ip_gateway = True
    #             else:
    #                 ip_gateway = False
    #     else:
    #         ip_gateway = True
    #     if ip_gateway:
    #         print("yeah",ip)
    #         kurs = db.cursor()
    #         # kurs.execute("SELECT * FROM request_infos WHERE ip = :aipi AND request_time > :mindro",{"aipi" : str(ip),"mindro" : int(time.time()) - 3600 })
    #         kurs.execute("SELECT * FROM request_infos WHERE request_infos_ip = %(aipi)s AND request_infos_request_time > %(mindro)s",{"aipi" : str(ip),"mindro" : int(time.time()) - 3600 })
            
    #         kursf = kurs.fetchall()
    #         print("amitimi",len(kursf))
    #         # kurs.execute("CREATE TABLE request_infos(request_infos_id INTEGER PRIMARY KEY AUTOINCREMENT, request_infos_ip VARCHAR(20), request_infos_header_info VARCHAR(1500), request_infos_request_name VARCHAR(50),request_infos_request_date VARCHAR(40), request_infos_payload VARCHAR(100), request_infos_request_time INTEGER, request_infos_the_search VARCHAR(70));  ")

    #         kurs.execute("INSERT INTO request_infos(request_infos_ip  ,request_infos_header_info    ,request_infos_request_name   ,request_infos_request_date   ,       request_infos_payload , request_infos_request_time  ) VALUES(%s,%s,%s,%s,%s,%s)",(ip,header,url_name,str(datetime.datetime.now()),json.dumps(payload),int(time.time()) ))
    #         # maxnum = 50
    #         maxnum = 5000000000
            
    #         if len(kursf) < maxnum:
                
    #             db.commit()
    #             resbool =  True
    #         else:
    #             resbool =  "too much requets"
    #         return {"resbool" : resbool, "ip" : ip,"kurs" : kurs}
    #     else:
    #         return "blocked_ip"




@app.errorhandler(404)
def page_notfound(e):
    print("cook",request.headers.get("Content-Type"))

    reqap = reqapprove(request,"/")
    if reqap["resbool"] == True:
        # if request.args.get("type")  =="dynamic":
            
            # return root_proccess(render_template("index.html"))
        # else:
            # return render_template("index.html",bg=Markup(render_template("bg.html")))
        authi = auth(request.cookies.get("c_user"),request.cookies.get("xs"))
        c_user = request.cookies.get("c_user")
        xs = request.cookies.get("xs")
        print("bendou")
        
        if authi == True:
            loggedin_bool = "true"
            db = sqlite3.connect()
            kurs = db.cursor()
            kurs.execute("SELECT * FROM users WHERE id = %(id)s",{"id" : int(request.cookies.get("c_user"))})
            kursf = kurs.fetchone()
            if premium(c_user,xs) == True:
                profile_info_arr_bgcolor = "#cab333"
            else:
                profile_info_arr_bgcolor = "white"
            navbar_authed = Markup(render_template("navbar_authed.html",mail=kursf[2], profile_info_arr_bgcolor=profile_info_arr_bgcolor))
            unauthed_reglog = ""
            unauthed_reglog_mob = ""
        else:
            loggedin_bool = "false"
            navbar_authed = ""
            

            unauthed_reglog = Markup("""
                    <h3 id = "registracia" class = "account_access_label">რეგისტრაცია</h3>
                    <h3 id = "avtorizacia" class = "account_access_label">ავტორიზაცია</h3>
                """)
            unauthed_reglog_mob = Markup("""
            <div id = "mobile_navbar_btn">
                <svg viewBox="0 0 100 80" width="40" height="40">
                    <rect width="100" height="20" fill = "white"></rect>
                    <rect y="30" width="100" fill="white" height="20"></rect>
                    <rect y="60" width="100" fill = "white" height="20"></rect>
                </svg>
            </div> 
                <div id = "mobile_navbar">
                    <div id = "mobile_navbar_cancell_btn"></div>
                    <h3 class = "mob_account_access_label" id ="mob_registracia">რეგისტრაცია</h3>
                    <h3 class = "mob_account_access_label" id = "mob_avtorizacia">ავტორიზაცია</h3>
                    
                </div>
            """)
        
        return render_template("pause.html",authed=str(authi),premium=str(premium(c_user,xs)),bg=Markup(render_template("bg.html")) , navbar_authed=navbar_authed,unauthed_reglog=unauthed_reglog,unauthed_reglog_mob=unauthed_reglog_mob ,loggedin_bool=loggedin_bool)
        
    else:
        return reqap["resbool"]





app.run(debug=False,port=80,host="0.0.0.0")

