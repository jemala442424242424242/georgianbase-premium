import socket
import mysql.connector
import os
import numpy as np
import sys
import threading
import json

# os.system("python C:\Users\User\Desktop\geobase_nonproduction\app.py")

def d2nparray_dimension_twist(ls):
    finls = np.array([])
    x = 0
    while x < ls.shape[1]:
        finls = np.append(finls,ls[:,x])
        x+=1
    finls = finls.reshape((ls.shape[1],ls.shape[0]))
    return finls
    


s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

porti = 5001

remote_ip = "192.168.1.21"
myip = "192.168.1.11"



host = "127.0.0.1"
user = "root"
passwd = ""
database = "geobase"


db = mysql.connector.connect(
    host=host,
    user=user,
    passwd = passwd,
    database= database
)

kurs = db.cursor()

# acc_upgrades
# ref_invites
# request_infos
# saved_rows
# searches
# users

transfarable_tables = ['acc_upgrades', 'ref_invites', 'request_infos', 'saved_rows', 'searches', 'users']
transfarable_tables_ports = [5031,5032,5033,5034,5035,5036]

acc_upgrades = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
ref_invites = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
request_infos = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
saved_rows = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
searches = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
users = socket.socket(socket.AF_INET,socket.SOCK_STREAM)


# CREATE TABLE the_database(pir_nomeri BIGINT, gvari VARCHAR(32), saxeli VARCHAR(30), mama VARCHAR(30), sqesi VARCHAR(3), dabweli VARCHAR(10), qucha VARCHAR(76), reg VARCHAR(13)    );
# CREATE TABLE person_searches(id INTEGER PRIMARY KEY AUTO_INCREMENT, payload VARCHAR(100), c_user INTEGER, ip VARCHAR(16), search_time  INTEGER);

# CREATE TABLE request_infos(request_infos_id INTEGER PRIMARY KEY AUTOINCREMENT, request_infos_ip VARCHAR(16), request_infos_header_info VARCHAR(1500), request_infos_request_name VARCHAR(50),request_infos_request_date VARCHAR(40), request_infos_request_time INTEGER, request_infos_the_search VARCHAR(70));  
# CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, ip VARCHAR(16), mail VARCHAR(40), password VARCHAR(100), vcode MEDIUMINT , user_creation_time INTEGER, refstr VARCHAR(50) )
# CREATE TABLE saved_rows(row_id INTEGER PRIMARY KEY AUTOINCREMENT, saver_id INTEGER, piradobis_nomeri_id BIGINT)
# CREATE TABLE searches(search_id INTEGER PRIMARY KEY AUTOINCREMENT, searcher_ip VARCHAR(16))
# CREATE TABLE acc_upgrades(acc_upgrade_id INTEGER PRIMARY KEY AUTOINCREMENT, upgraded_acc_id INTEGER, acc_upgrade_time INTEGER, acc_upgrade_duration INTEGER ); 
# CREATE TABLE ref_invites( ref_invite_id  INTEGER PRIMARY KEY AUTOINCREMENT, ref_inviter_id INTEGER) ;




# CREATE TABLE ref_invites( ref_invite_id  INTEGER PRIMARY KEY AUTOINCREMENT, ref_inviter_id INTEGER) ;")




def npdata_to_pydata(x):
    if "str" in   str(type(x)):
        return str(x)
    elif "float" in str(type(x)):
        return float(x)
    elif "int" in str(type(x)):
        return int(x) 







host_up = os.system("ping " + remote_ip)

print(host_up)
if host_up == 0: # tu hosti dahostilia, jamshi 6 table

# if False:
    
    # acc_upgrades
    # ref_invites
    # request_infos
    # saved_rows
    # searches
# the_database
    # users
    # kurs = db.cursor()

    kurs.execute("DELETE FROM acc_upgrades")
    kurs.execute("DELETE FROM ref_invites")
    kurs.execute("DELETE FROM request_infos")
    kurs.execute("DELETE FROM saved_rows")
    kurs.execute("DELETE FROM searches")
    kurs.execute("DELETE FROM users")
    
    s.connect((remote_ip,porti))

    data_measurements_pack = s.recv(1024)
    data_measurements = json.loads(data_measurements_pack.decode('utf-8'))

    s.send(bytes("ping","utf-8"))
    completed_transforms = []
    
    def complete_transform(name):
        completed_transforms.append(name)

        if len(completed_transforms) == 6:
            pass

    def acc_upgrades_f():
        acc_upgrades.connect((remote_ip,transfarable_tables_ports[0]))
        data = acc_upgrades.recv(int(data_measurements["acc_upgrades"]))
        dtypes =[("acc_upgrade_id","int32"),("upgraded_acc_id","int32"),("acc_upgrade_time","int32"),("acc_upgrade_duration","int32")]
        monac = np.frombuffer(data,dtype=dtypes)
        # kurs = db.cursor()
        for i in monac:
            i = tuple(map(npdata_to_pydata,i))
            kurs.execute("INSERT INTO acc_upgrades(acc_upgrade_id,upgraded_acc_id,acc_upgrade_time,acc_upgrade_duration) VALUES(%s,%s,%s,%s)",(i[0],i[1],i[2],i[3]))#,multi=True)
        complete_transform("acc_upgrades")
    def ref_invites_f():
        # msg = "ping"#json.dumps({"result" : "success", "type" : "table_query_array_recieveconfirm"})
        # s.send(bytes(msg,"utf-8"))
        ref_invites.connect((remote_ip,transfarable_tables_ports[1]))

        dtypes = [("ref_invite_id","int32"), ("ref_inviter_id","int32")]

        data = ref_invites.recv(data_measurements["ref_invites"])
        monac = np.frombuffer(data,dtype=dtypes)
        # kurs = db.cursor()
        for i in monac:# CREATE TABLE ref_invites( ref_invite_id  INTEGER PRIMARY KEY AUTOINCREMENT, ref_inviter_id INTEGER) ;

            i = tuple(map(npdata_to_pydata,i))
            kurs.execute("INSERT INTO ref_invites(ref_invite_id ,ref_inviter_id) VALUES(%s,%s);",(i[0], i[1]))#,multi=True)
        #kursexecute
        #kurs.close()
        complete_transform("ref_invites")
    def request_infos_f():
        # kurs.execute("SELECT request_infos_id, request_infos_ip, request_infos_request_time FROM request_infos;")
        # msg = "ping"#json.dumps({"result" : "success", "type" : "table_query_array_recieveconfirm"})
        # s.send(bytes(msg,"utf-8"))

        request_infos.connect((remote_ip,transfarable_tables_ports[2]))
        dtypes = [("request_infos_id","int32"), ("request_infos_ip","<U16"), ("request_infos_request_time","int32")]
        data = request_infos.recv(int(data_measurements["request_infos"]))
        monac = np.frombuffer(data,dtype=dtypes)
        # kurs = db.cursor()
        for i in monac:
            i = tuple(map(npdata_to_pydata,i))
            kurs.execute("INSERT INTO request_infos(request_infos_id,request_infos_ip,request_infos_request_time) VALUES(%s,%s,%s);",(i[0], i[1],i[1]))#,multi=True)

        #kursexecute
        #kurs.close()
        complete_transform("request_infos")
    def saved_rows_f():
        # msg = "ping"#json.dumps({"result" : "success", "type" : "table_query_array_recieveconfirm"})
        # s.send(bytes(msg,"utf-8"))
        saved_rows.connect((remote_ip,transfarable_tables_ports[3]))

        dtypes = [("row_id","int32"), ("saver_id","int32"), ("piradobis_nomeri_id","int64")]
        data = saved_rows.recv(int(data_measurements["saved_rows"]))
        monac = np.frombuffer(data,dtype=dtypes)
        # kurs = db.cursor()
        for i in monac:# CREATE TABLE saved_rows(row_id INTEGER PRIMARY KEY AUTOINCREMENT, saver_id INTEGER, piradobis_nomeri_id BIGINT)

            i = tuple(map(npdata_to_pydata,i))
            kurs.execute("INSERT INTO saved_rows(row_id,saver_id,piradobis_nomeri_id) VALUES(%s,%s,%s);",(i[0],i[1],i[2]))#,multi=True)

        #kursexecute
        #kurs.close()
        complete_transform("saved_rows")
    def searches_f():
        # msg = "ping"#json.dumps({"result" : "success", "type" : "table_query_array_recieveconfirm"})
        # s.send(bytes(msg,"utf-8"))
        searches.connect((remote_ip,transfarable_tables_ports[4]))

        dtypes = [("search_id","int32"), ("searcher_ip","<U16")]
        data = searches.recv(int(data_measurements["searches"]))
        monac = np.frombuffer(data,dtype=dtypes)
        # CREATE TABLE searches(search_id INTEGER PRIMARY KEY AUTOINCREMENT, searcher_ip VARCHAR(16))
        # kurs = db.cursor()
        for i in monac:
            i = tuple(map(npdata_to_pydata,i))
            kurs.execute("INSERT INTO searches(search_id,searcher_ip) VALUES(%s,%s);",(  i[0],str(i[1])  ) )#,multi=True)

        #kursexecute
        #kurs.close()
        complete_transform("searches")
    def users_f():
        # msg = "ping"#json.dumps({"result" : "success", "type" : "table_query_array_recieveconfirm"})
        # s.send(bytes(msg,"utf-8"))
        users.connect((remote_ip,transfarable_tables_ports[5]))
        dtypes = [("id","int32"),("ip","<U16"), ("mail","<U40"), ("password","<U100"), ("vcode","int32"),("user_creation_time","int32"), ("refstr","<U50")]
        
        data = users.recv(int(data_measurements["users"]))

        monac = np.frombuffer(data,dtype=dtypes)
        # CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, ip VARCHAR(16), mail VARCHAR(40), password VARCHAR(100), vcode MEDIUMINT , user_creation_time INTEGER, refstr VARCHAR(50) )
        # kurs = db.cursor()

        for i in monac:
            i = tuple(map(npdata_to_pydata,i))
            kurs.execute("INSERT INTO users(id,ip,mail,password,vcode,user_creation_time,refstr) VALUES(%s,%s,%s,%s,%s,%s,%s);",(i[0],i[1],i[2],i[3],i[4],i[5],i[6]))#,multi=True)
        #kursexecute
        #kurs.close()
        complete_transform("users")
    # def ():
    #     msg = "ping"#json.dumps({"result" : "success", "type" : "table_query_array_recieveconfirm"})
    #     s.send(bytes(msg,"utf-8"))


    if int(data_measurements["acc_upgrades"]) != 33:
        acc_upgrades_t = threading.Thread(target=acc_upgrades_f)
        acc_upgrades_t.start()
        acc_upgrades_t.join()
        
    else:
        complete_transform("acc_upgrades")
    
    if int(data_measurements["ref_invites"]) != 33:
        ref_invites_t = threading.Thread(target=ref_invites_f)
        ref_invites_t.start()
        ref_invites_t.join()
        
    else:
        complete_transform("ref_invites")
    
    if int(data_measurements["request_infos"]) != 33:
        request_infos_t = threading.Thread(target=request_infos_f)
        request_infos_t.start()
        request_infos_t.join()
    else:
        
        complete_transform("request_infos")

    if int(data_measurements["saved_rows"]) != 33:
        saved_rows_t = threading.Thread(target=saved_rows_f)
        saved_rows_t.start()
        saved_rows_t.join()
    else:

        complete_transform("saved_rows")
    if int(data_measurements["searches"]) != 33:
        searches_t = threading.Thread(target=searches_f)
        searches_t.start()
        searches_t.join()
    else:
        complete_transform("searches")

    if int(data_measurements["users"]) != 33:
        users_t = threading.Thread(target=users_f)
        users_t.start()
        users_t.join()
    else:
        complete_transform("users")

    x = 0
    while True:
        
        if len(completed_transforms) == 6:
            db.commit()
            break

        x+=1
        if (x % 100000) == 0:
            print(completed_transforms) 

    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

    acc_upgrades = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    ref_invites = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    request_infos = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    saved_rows = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    searches = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    users = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
print("bot is hosting...")
s.bind((myip,porti))

threading.Thread(target= lambda : os.system("python app.py")).start()
s.listen(3)


# while True:
client, addr = s.accept()
    # acc_upgrades
    # ref_invites
    # request_infos
    # saved_rows
    # searches
# the_database
    # users
    

print("daiwyo bazis transferis gagzavna")
 

db = mysql.connector.connect(
host=host,
user=user,
passwd = passwd,
database= database
)
kurs = db.cursor()

completed_transforms = []
# acc_upgrades
# ref_invites
# request_infos
# saved_rows
# searches
# users

kurs.execute("SELECT * FROM acc_upgrades;")

acc_upgradesnf = kurs.fetchall()
if acc_upgradesnf == []:
    acc_upgradesnpb = np.array([]).tobytes()
    acc_upgrades_size = 33
else:
    acc_upgradesn = np.array(acc_upgradesnf)

    acc_upgradesnp = np.core.records.fromarrays(acc_upgradesn.transpose()
                                            ,formats = "int32, int32, int32, int32 ")

    acc_upgradesnpb = acc_upgradesnp.tobytes()

    acc_upgrades_size = sys.getsizeof(acc_upgradesnpb)










kurs.execute("SELECT * FROM ref_invites;")

ref_invitesf = kurs.fetchall()
if ref_invitesf == []:
    ref_invitesnpb = np.array([]).tobytes()
    ref_invites_size = 33

else:    
    ref_invitesn = np.array(ref_invitesf)

    ref_invitesnp = np.core.records.fromarrays(ref_invitesn.transpose()
                                            ,formats = "int32, int32 ")

    ref_invitesnpb = ref_invitesnp.tobytes()

    ref_invites_size = sys.getsizeof(ref_invitesnpb)













kurs.execute("SELECT request_infos_id, request_infos_ip, request_infos_request_time FROM request_infos;")

request_infosf = kurs.fetchall()

if request_infosf == []:
    request_infosnpb = np.array([]).tobytes()
    request_infos_size = 33
else:
    request_infosn = np.array(request_infosf)

    request_infosnp = np.core.records.fromarrays(request_infosn.transpose()
                                            ,formats = "int32, <U16, int32 ")
    request_infosnpb = request_infosnp.tobytes()

    request_infos_size = sys.getsizeof(request_infosnpb)












kurs.execute("SELECT row_id , saver_id, piradobis_nomeri_id FROM saved_rows;")

saved_rowsf = kurs.fetchall()

if saved_rowsf == []:
    saved_rowsnpb = np.array([]).tobytes()
    saved_rows_size = 33
else:

    saved_rowsn = np.array(saved_rowsf)

    saved_rowsnp = np.core.records.fromarrays(saved_rowsn.transpose()
                                            ,formats = "int32, int32, int64 ")

    saved_rowsnpb = saved_rowsnp.tobytes()

    saved_rows_size = sys.getsizeof(saved_rowsnpb)












kurs.execute("SELECT search_id , searcher_ip FROM searches;")

searchesf = kurs.fetchall()

if searchesf == []:
    searchesnpb = np.array([]).tobytes()
    searches_size = 33
else:
    searchesn = np.array(searchesf)

    searchesnp = np.core.records.fromarrays(searchesn.transpose()
                                            ,formats = "int32, <U16 ")

    searchesnpb = searchesnp.tobytes()

    searches_size = sys.getsizeof(searchesnpb)















kurs.execute("SELECT id, ip, mail, password, vcode, user_creation_time, refstr FROM users;")

usersf = kurs.fetchall()
if usersf == []:
    usersnpb = np.array([]).tobytes()
    users_size = 33
else:
    usersn = np.array(usersf)

    usersnp = np.core.records.fromarrays(usersn.transpose()
                                            ,formats = "int32, <U16, <U40, <U100, int32, int32, <U50 ")

    usersnpb = usersnp.tobytes()

    users_size= sys.getsizeof(usersnpb)




data_measurements = {
    "acc_upgrades" : acc_upgrades_size,
    "ref_invites" : ref_invites_size,
    "request_infos" : request_infos_size,
    "saved_rows" : saved_rows_size,
    "searches" : searches_size,
    "users" : users_size
}



print("igzavneba",data_measurements)
client.send(bytes(json.dumps(data_measurements),"utf-8"))










def acc_upgrades_f():

    acc_upgrades.bind((myip,transfarable_tables_ports[0]))

    acc_upgrades.listen(5)

    client,addr= acc_upgrades.accept()
    

    
    client.send(acc_upgradesnpb)

    completed_transforms.append("acc_upgrades")









def ref_invites_f():


    # morchenis_ping = client.recv(64)s
    ref_invites.bind((myip,transfarable_tables_ports[1]))

    ref_invites.listen(5)

    client,addr= ref_invites.accept()
    

    

    client.send(ref_invitesnpb)

    completed_transforms.append("ref_invites")








def request_infos_f():

    #morchenis_ping = client.recv(64)
    request_infos.bind((myip,transfarable_tables_ports[2]))

    request_infos.listen(5)

    client,addr= request_infos.accept()

    

    client.send(request_infosnpb)

    completed_transforms.append("request_infos")








def saved_rows_f():



    #morchenis_ping = client.recv(64)
    saved_rows.bind((myip,transfarable_tables_ports[3]))

    saved_rows.listen(5)

    client,addr= saved_rows.accept()

    

    client.send(saved_rowsnpb)

    completed_transforms.append("saved_rows")










def searches_f():

    #morchenis_ping = client.recv(64)
    searches.bind((myip,transfarable_tables_ports[4]))

    searches.listen(5)

    client,addr= searches.accept()

    

    client.send(searchesnpb)


    completed_transforms.append("searches")







def users_f():

    #morchenis_ping = client.recv(64)
    # kurs.execute("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, ip VARCHAR(16), mail VARCHAR(40), password VARCHAR(100), vcode MEDIUMINT , user_creation_time INTEGER, refstr VARCHAR(50) )")
    users.bind((myip,transfarable_tables_ports[5]))

    users.listen(5)

    client,addr= users.accept()

    print("new connection",addr,transfarable_tables_ports[5])

    client.send(usersnpb)
    print('userstable sent')

    completed_transforms.append("users")


if acc_upgrades_size == 33:
    completed_transforms.append("acc_upgrades")
else:
    threading.Thread(target=acc_upgrades_f).start()

if ref_invites_size == 33:
    completed_transforms.append("ref_invites")
else:
    threading.Thread(target=ref_invites_f).start()
if request_infos_size == 33:
    completed_transforms.append("request_infos")
else:
    threading.Thread(target=request_infos_f).start()

if saved_rows_size == 33:
    completed_transforms.append("saved_rows")
else:
    threading.Thread(target=saved_rows_f).start()

if searches_size == 33:
    completed_transforms.append("searches")
else:
    threading.Thread(target=searches_f).start()

if searches_size == 33:
    completed_transforms.append("users")
else:
    threading.Thread(target=users_f).start()



while True:
    print(completed_transforms)
    if len(completed_transforms) == 6:
        print("os shutdown /s /t 1")

        break



